#!/bin/bash
. $HOME/.bash_profile
source /home/sdlreco/crons/config/recon.sh

conda activate pyreco_3.9_v1.1

now=`date +"%Y-%m-%d"`
python /home/sdlreco/crons/recharge/recharge.py 1>>/home/sdlreco/crons/recharge/out/out-${now}.txt 2>>/home/sdlreco/crons/recharge/error/error-${now}.txt
