#!/bin/bash
. $HOME/.bash_profile
source /home/sdlreco/crons/config/recon.sh

now=`date +"%Y-%m-%d"`
python /home/sdlreco/crons/wallet_ecollection/wallet_ecollection.py 1>>/home/sdlreco/crons/wallet_ecollection/out/out-${now}.txt 2>>/home/sdlreco/crons/wallet_ecollection/error/error-${now}.txt