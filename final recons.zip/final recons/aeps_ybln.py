import numpy as np
import pandas as pd
import fsspec
import time
from google.cloud import bigquery
from datetime import datetime
from datetime import date as d
import datetime as dt
import os
from google.oauth2 import service_account
from google.cloud import storage
from datetime import timedelta

import warnings
warnings.filterwarnings('ignore', category=UserWarning, module='openpyxl')

dates = d.today()
times = datetime.now()

f = open('/home/sdlreco/crons/aeps_ybln/stat/stat-'+str(dates)+'.txt', 'a+')
f.close()

fa=open('/home/sdlreco/crons/aeps_ybln/error/missing-'+str(dates)+'.txt', 'w')
fa.close()


dates = d.today()
times = datetime.now()



key_path='C:/Users/roop.sidhu_spicemone/Downloads/roop-sidhu.json'

def main():
    date = d.today()-timedelta(1)
    current_date5 = date.strftime('%d-%m-%Y')

    date = d.today()-timedelta(1)
    current_date2 = date.strftime('%d-%m-%Y')

    date = d.today()-timedelta(2)
    current_date3 = date.strftime('%d-%m-%Y')

    date = d.today()
    current_date4 = date.strftime('%d-%m-%Y')

    date = d.today()
    current_date6 = date.strftime('%Y%m%d')

    current_date = d.today()-timedelta(1)

    date = d.today()
    current_year = date.strftime('%Y')

    date = d.today()
    current_month = date.strftime('%m')

    date = d.today()
    current_day = date.strftime('%d')
    
      
    project_id = 'spicemoney-dwh'
    client = bigquery.Client(project=project_id, location='asia-south1')
   
    file_exists = []
    try:
        pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLDMTBalance summery/BalanceSummaryDetails Report-'+'*'+'/BalanceSummaryDetails Report-'+'*.csv')  
        file_exists.append(True)

    except:
        file_exists.append(False) 
        
        with open('/home/sdlreco/crons/aeps_ybln/error/missing-'+str(dates)+'.txt', 'a+') as f:
            f.write(str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLDMTBalance summery/BalanceSummaryDetails Report-'+'*'+'/BalanceSummaryDetails Report-'+'*.csv')
            f.write('\n')    
    
    try:
        pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLDMTBalance summery/partnerthreshold-Report-'+'*'+'/partnerthreshold-Report-'+'*.csv')  
        file_exists.append(True)

    except:
        file_exists.append(False) 
        
        with open('/home/sdlreco/crons/aeps_ybln/error/missing-'+str(dates)+'.txt', 'a+') as f:
            f.write(str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLDMTBalance summery/partnerthreshold-Report-'+'*'+'/partnerthreshold-Report-'+'*.csv')
            f.write('\n')    
                    
    try:
        pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLN MaximusAEPSTransactions Report/AEPS Transaction Report_'+str(current_day)+'-'+str(current_month)+'-'+str(current_year)+'*.csv')  
        file_exists.append(True)

    except:
        file_exists.append(False) 
        
        with open('/home/sdlreco/crons/aeps_ybln/error/missing-'+str(dates)+'.txt', 'a+') as f:
            f.write(str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLN MaximusAEPSTransactions Report/AEPS Transaction Report_'+str(current_day)+'-'+str(current_month)+'-'+str(current_year)+'*.csv')
            f.write('\n') 
            
    try:
        print('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLAEPSBank Settlement/YBL_BS_'+str(current_year)+str(current_month)+str(current_day)+'*.CSV')
        pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLAEPSBank Settlement/YBL_BS_'+str(current_year)+str(current_month)+str(current_day)+'*.CSV')  
        file_exists.append(True)

    except:
        file_exists.append(False) 
        
        with open('/home/sdlreco/crons/aeps_ybln/error/missing-'+str(dates)+'.txt', 'a+') as f:
            f.write(str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLAEPSBank Settlement/YBL_BS_'+str(current_year)+str(current_month)+str(current_day)+'*.CSV')
            f.write('\n') 
            
    
        
    if False in file_exists:
      print('Files missing : Logged at -- /home/sdlreco/crons/aeps_ybln/error/missing-'+str(dates)+'.txt')

    else:

        print('All files found, Processing ...')
        # bank statement
        #log file 1
        project_id = 'spicemoney-dwh'

        client = bigquery.Client( project=project_id, location='asia-south1')
        #---------------------------------------------------------------------------------------------------------------------
        #Loading AEPS-YBL Bank Summary into the database
        #---------------------------------------------------------------------------------------------------------------------
    
        print("Data movement started to ts_aeps_ybln_bank_summary table")
        schema = [{'name':'partner_name','type':'STRING'},
                    {'name':'sor_txn_id','type':'STRING'},
                    {'name':'req_txn_id','type':'STRING'},
                    {'name':'rrn','type':'STRING'},
                    {'name':'txn_amount','type':'FLOAT'},
                    {'name':'txn_fee','type':'FLOAT'},
                    {'name':'txn_status','type':'STRING'},
                    {'name':'debit_amt','type':'FLOAT'},
                    {'name':'credit_amt','type':'FLOAT'},
                    {'name':'payment_mode','type':'STRING'},
                    {'name':'log_txn_time','type':'DATETIME'},
                    {'name':'txn_initiated_date','type':'DATE'}
                ]
                    
        #Specifying the header column            
        header_list = ['partner_name',
                        'sor_txn_id',
                        'req_txn_id',
                        'rrn',
                        'txn_amount',
                        'txn_fee',
                        'txn_status',
                        'debit_amt',
                        'credit_amt',
                        'payment_mode',
                        'log_txn_time',
                        'txn_initiated_date'
                        ]
        
        list1= ['partner_name',
                        'sor_txn_id',
                        'req_txn_id',
                        'rrn',
                        'txn_status',
                        'payment_mode']
        list2=['txn_amount',
               'txn_fee',
               'debit_amt',
                'credit_amt']
        #sm-prod-rpa/2022/10/01/YBLDMTBalance summery/BalanceSummaryDetails Report-BTKcYc/BalanceSummaryDetails Report-BTKcYc.csv
        print('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLDMTBalance summery/BalanceSummaryDetails Report-'+'*'+'/BalanceSummaryDetails Report-'+'*.csv')
                    # Reading data from excel to dataframe            
        df = pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLDMTBalance summery/BalanceSummaryDetails Report-'+'*'+'/BalanceSummaryDetails Report-'+'*.csv',skiprows=1,names=header_list,header=None,parse_dates = (['log_txn_time','txn_initiated_date']), low_memory=False)  

        
        conditions = [(df['req_txn_id'].str.contains('MAX')) &  (df['payment_mode'].str.contains('CREDIT-AEPS'))]

        rrn= df['req_txn_id'].str[3:]

        values = [rrn]
        
        df['rrn'] = np.select(conditions, values)

        
        
        df[list1]=df[list1].astype(str)
        df[list2]=df[list2].astype(float)
        
        df.to_gbq(destination_table='sm_recon.ts_aeps_ybln_bank_summary', project_id='spicemoney-dwh', if_exists='replace' , table_schema = schema)
        print("Data moved to ts_aeps_ybln_bank_summary table")
        df.to_gbq(destination_table='prod_sm_recon.prod_aeps_ybln_bank_summary', project_id='spicemoney-dwh', if_exists='append' , table_schema = schema)
        print("Data moved to prod_aeps_ybln_bank_summary table")
        print("---------------------------------------------------------")
        
        
        #---------------------------------------------------------------------------------------------------------------------
        #Loading AEPS-YBL Threshhold Summary into the database
        #---------------------------------------------------------------------------------------------------------------------
        print("Data movement started to ts_aeps_ybln_threshhold_report table")
        schema_thresh = [{'name':'partner_name','type':'STRING'},
                    {'name':'transaction_id','type':'STRING'},
                    {'name':'rrn','type':'STRING'},
                    {'name':'amount','type':'FLOAT'},
                    {'name':'txn_type','type':'STRING'},
                    {'name':'transaction_date','type':'DATETIME'},
                    {'name':'status','type':'STRING'},
                    {'name':'response_message','type':'STRING'},
                    {'name':'payment_mode','type':'STRING'},
                    {'name':'is_reverted','type':'STRING'},
                    {'name':'partner_txn_id','type':'STRING'},
                    {'name':'remarks','type':'STRING'},
                    {'name':'txn_date','type':'DATE'},
                    {'name':'agent_id','type':'STRING'}
                ]
                    
        #Specifying the header column            
        header_list_thresh = ['partner_name',
                        'transaction_id',
                        'rrn',
                        'amount',
                        'txn_type',
                        'transaction_date',
                        'status',
                        'response_message',
                        'payment_mode',
                        'is_reverted',
                        'partner_txn_id',
                        'remarks',
                        'txn_date',
                        'agent_id'
                        ]
        
        list1_thresh= ['partner_name',
                        'transaction_id',
                        'rrn',
                        'txn_type',
                        'status',
                        'response_message',
                        'payment_mode',
                        'is_reverted',
                        'partner_txn_id',
                        'remarks',
                        'agent_id']
        list2_thresh=['amount']
        #sm-prod-rpa/2022/10/01/YBLDMTBalance summery/partnerthreshold-Report-wjzUmz/partnerthreshold-Report-wjzUmz.csv
        print('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLDMTBalance summery/partnerthreshold-Report-'+'*'+'/partnerthreshold-Report-'+'*.csv')
                    # Reading data from excel to dataframe            
        df_thresh = pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLDMTBalance summery/partnerthreshold-Report-'+'*'+'/partnerthreshold-Report-'+'*.csv',skiprows=1,names=header_list_thresh,header=None,parse_dates = (['transaction_date','txn_date']), low_memory=False)  

        conditions = [(df_thresh['partner_txn_id'].str.contains('MAX')) &  (df_thresh['payment_mode'].str.contains('CREDIT-AEPS'))]

        rrn= df_thresh['partner_txn_id'].str[3:]

        values = [rrn]
        
        df_thresh['rrn'] = np.select(conditions, values)

        
        
        df_thresh[list1_thresh]=df_thresh[list1_thresh].astype(str)
        df_thresh[list2_thresh]=df_thresh[list2_thresh].astype(float)
        
        df_thresh.to_gbq(destination_table='sm_recon.ts_aeps_ybln_threshhold_report', project_id='spicemoney-dwh', if_exists='replace' , table_schema = schema_thresh)
        print("Data moved to ts_aeps_ybln_threshhold_report table")
        df.to_gbq(destination_table='prod_sm_recon.prod_aeps_ybln_threshhold_report', project_id='spicemoney-dwh', if_exists='append' , table_schema = schema_thresh)
        print("Data moved to prod_aeps_ybln_threshhold_report table")
        print("---------------------------------------------------------")
        
        #---------------------------------------------------------------------------------------------------------------------
        #Loading AEPS-Transaction Report into the database
        #---------------------------------------------------------------------------------------------------------------------
        print("Data movement started to ts_aeps_transaction_report table")
       

        schema_tran_rpt=[
            {'name':'transaction_type','type':'STRING'},
            {'name':'transaction_amt','type':'FLOAT'},
            {'name':'partner_ref_number','type':'STRING'},
            {'name':'transaction_date_time','type':'STRING'},
            {'name':'rrn','type':'STRING'},
            {'name':'auth_code','type':'STRING'},
            {'name':'terminal_id','type':'STRING'},
            {'name':'aggregator_name','type':'STRING'},
            {'name':'agent_id','type':'STRING'},
            {'name':'iin','type':'STRING'},
            {'name':'resp_code','type':'STRING'},
            {'name':'transaction_status','type':'STRING'}]
        
                    
        #Specifying the header column            
        header_tran_rpt = ['transaction_type',
                            'transaction_amt',
                            'partner_ref_number',
                            'transaction_date_time',
                            'rrn',
                            'auth_code',
                            'terminal_id',
                            'aggregator_name',
                            'agent_id',
                            'iin',
                            'resp_code',
                            'transaction_status'
                        ]
        
        list1_tran_rpt= ['transaction_type',
                            'partner_ref_number',
                            'transaction_date_time',
                            'rrn',
                            'auth_code',
                            'terminal_id',
                            'aggregator_name',
                            'agent_id',
                            'iin',
                            'resp_code',
                            'transaction_status']
        
        list2_tran_rpt=['transaction_amt']
        
        #sm-prod-rpa/2022/10/21/YBLN MaximusAEPSTransactions Report/AEPS Transaction Report_21-10-2022 07_06_11.csv 
        print('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLN MaximusAEPSTransactions Report/AEPS Transaction Report_'+str(current_day)+'-'+str(current_month)+'-'+str(current_year)+'*.csv')
        #df_tran_rpt = pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLN MaximusAEPSTransactions Report/AEPS Transaction Report_'+str(current_day)+'-'+str(current_month)+'-'+str(current_year)+'*.csv',index_col=False,skiprows=1,names=header_tran_rpt,header=None,parse_dates = (['transaction_date_time']), low_memory=False,storage_options={"token": key_path})  
        df_tran_rpt = pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLN MaximusAEPSTransactions Report/AEPS Transaction Report_'+str(current_day)+'-'+str(current_month)+'-'+str(current_year)+'*.csv',index_col=False,skiprows=1,names=header_tran_rpt,header=None,parse_dates = (['transaction_date_time']), low_memory=False)  
       
        #print(df_tran_rpt)
        
        df_tran_rpt['partner_ref_number']=df_tran_rpt['partner_ref_number'].str.replace(r"'",'')
        df_tran_rpt['rrn']=df_tran_rpt['rrn'].str.replace(r"'",'')
        df_tran_rpt['resp_code']=df_tran_rpt['resp_code'].str.replace(r"'",'')
        #print(df_tran_rpt)
        
        
        df_tran_rpt[list1_tran_rpt]=df_tran_rpt[list1_tran_rpt].astype(str)
        
        df_tran_rpt['transaction_amt']=df_tran_rpt['transaction_amt'].astype(float)
        
        df_tran_rpt.to_gbq(destination_table='sm_recon.ts_aeps_ybln_transaction_report', project_id='spicemoney-dwh', if_exists='replace' , table_schema = schema_tran_rpt)
        print("Data moved to ts_aeps_ybln_transaction_report table")
        df.to_gbq(destination_table='prod_sm_recon.prod_aeps_ybln_transaction_report', project_id='spicemoney-dwh', if_exists='append' , table_schema = schema_tran_rpt)
        print("Data moved to prod_aeps_ybln_transaction_report table")
        print("---------------------------------------------------------")
        
        #---------------------------------------------------------------------------------------------------------------------
        #Loading YBLAEPSBank Settlement into the database
        #---------------------------------------------------------------------------------------------------------------------
        print("Data movement started to ts_aeps_ybln_bank_settlement table")
        
        schema_settlement=[
            {'name':'row_num','type':'STRING'},
            {'name':'txn_date','type':'DATETIME'},
            {'name':'cod_acct_no','type':'STRING'},
            {'name':'narration','type':'STRING'},
            {'name':'value_date','type':'STRING'},
            {'name':'cheque_no','type':'STRING'},
            {'name':'drcr_flag','type':'STRING'},
            {'name':'amount','type':'FLOAT'},
            {'name':'dat_post','type':'STRING'},
            {'name':'running_balance','type':'STRING'},
            {'name':'urn','type':'STRING'},
            {'name':'bank_ref_number','type':'STRING'}]
        
        
                  
        #Specifying the header column            
        header_settlement = ['row_num',
                            'txn_date',
                            'cod_acct_no',
                            'narration',
                            'value_date',
                            'cheque_no',
                            'drcr_flag',
                            'amount',
                            'dat_post',
                            'running_balance',
                            'urn',
                            'bank_ref_number'
                        ]
        
        list1_settlement= ['row_num',
                            'cod_acct_no',
                            'narration','value_date',
                            'cheque_no',
                            'drcr_flag','dat_post',
                            'running_balance',
                            'urn',
                            'bank_ref_number']
        
        list2_settlement=['amount']
        
        #sm-prod-rpa/2022/09/28/YBLAEPSBank Settlement/YBL_BS_20220928_001481400000290.CSV           
        print('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLAEPSBank Settlement/YBL_BS_'+str(current_year)+str(current_month)+str(current_day)+'*.CSV')
        df_settlement = pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/YBLAEPSBank Settlement/YBL_BS_'+str(current_year)+str(current_month)+str(current_day)+'*.CSV',index_col=False,skiprows=1,names=header_settlement,header=None, low_memory=False, parse_dates = (['txn_date']))                                                                                                                                                                     
        
        #print(df_settlement)
               
        df_settlement[list1_settlement]=df_settlement[list1_settlement].astype(str)
        df_settlement['amount']=df_settlement['amount'].astype(float)
        df_settlement.to_gbq(destination_table='sm_recon.ts_aeps_ybln_bank_settlement', project_id='spicemoney-dwh', if_exists='replace' ,table_schema = schema_settlement)
        print("Data moved to ts_aeps_ybln_bank_settlement table")
        df_settlement.to_gbq(destination_table='prod_sm_recon.prod_aeps_ybln_bank_settlement', project_id='spicemoney-dwh', if_exists='append' , table_schema = schema_settlement)
        print("Data moved to prod_aeps_ybln_bank_settlement table")
        
          #---------------------------------------------------------------------------------------------------------------------
        #--prod_aeps_ybln_spice_logs_not_in_ftr-1.Validate Spice Detail logs (Req Res Logs) with Agent FTR Logs (CME_Wallet)
        #---------------------------------------------------------------------------------------------------------------------
       
        print("prod_aeps_ybln_spice_logs_not_in_ftr data movement started")
        sql_query="""
        select LOG_DATE_TIME,CLIENT_ID,SPICE_TID
        ,SumOfSumOfTRANS_AMT,JDT_STAN,RC,MESSAGE,Unique_Identification_Number as FTR_ID from 
        (SELECT date(a.log_date_time) as LOG_DATE_TIME,a.client_id as CLIENT_ID,a.spice_tid as SPICE_TID, (a.trans_amt) as SumOfSumOfTRANS_AMT,b.jdt_stan as JDT_STAN, b.rc as RC, b.response_message as MESSAGE,b.response_code as Spice_Detail_logs_Response,master_trans_type
        FROM `spicemoney-dwh.prod_dwh.aeps_trans_req` a
        join
        `spicemoney-dwh.prod_dwh.aeps_trans_res_v2`b
        on a.request_id = b.request_id 
        WHERE date(a.log_date_time)=@date 
            and date(b.log_date_time) = @date and 
            b.rc = '00' and a.master_trans_type = 'CW'  and a.aggregator='YBLN'
        ) as t1
        LEFT JOIN
        (
        select unique_identification_no as Unique_Identification_Number, amount_transferred as Amount_Transferred , date(transfer_date) as Transfer_Date , distributor_retailer_trans_id as Distributor_Retailer_Trans_Id, transfer_mode  as Transfer_Mode, comments as Comments , ip_address as IP_Address , distr_wallet_id  as Distr_Wallet_Id
            from 
            `spicemoney-dwh.prod_dwh.cme_wallet`
            where  date(transfer_date) = @date and comments in ('AEPS RBL- Cash Withdrawal','AEPS-CASH WITHDRAWAL-MANUAL-CREDIT')
        ) as t2
        ON t1.SPICE_TID=t2.Unique_Identification_Number
        where SPICE_TID is not null and Unique_Identification_Number is  null 
        
        """
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_spice_logs_not_in_ftr', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_spice_logs_not_in_ftr', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_spice_logs_not_in_ftr data movement completed")
        
         #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_spice_logs_success_notfound_failed_maximus_logs
        #2.Update Missing RRN in Spice Detail logs from YBL Maximus Txn Report,Validate Spice Detail logs with YBL Maximus Txn Report
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_spice_logs_success_notfound_failed_maximus_logs data movement started")
        sql_query="""
                select TRANSDATE , JDT_STAN , SPICE_TID , Client_ID ,TRANSAMOUNT ,resp_code as YBL_Txn_Logs_Response
                from  
        (
        SELECT date(a.log_date_time) as TRANSDATE,b.jdt_stan as JDT_STAN,a.spice_tid as SPICE_TID,a.client_id as Client_ID
         , (a.trans_amt)as TRANSAMOUNT, b.rc, b.response_message ,a.request_id , b.request_id,  FROM `spicemoney-dwh.prod_dwh.aeps_trans_req` a 
        join `spicemoney-dwh.prod_dwh.aeps_trans_res_v2`b on a.request_id = b.request_id
        WHERE a.aggregator = 'YBLN' and a.master_trans_type = 'CW' and b.rc = '00' and DATE(a.log_date_time) = @date 
        and date(b.log_date_time) = @date 
        ) t1
        left join
        (select partner_ref_number,rrn , resp_code , transaction_amt from `spicemoney-dwh.sm_recon.ts_aeps_ybln_transaction_report`
        where date(transaction_date_time) = @date and transaction_type='Withdrawal'
        )t2
        on SPICE_TID = t2.partner_ref_number
        where (resp_code!='00') or rrn is null
        
        """
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_spice_logs_success_notfound_failed_maximus_logs', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_spice_logs_success_notfound_failed_maximus_logs', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_spice_logs_success_notfound_failed_maximus_logs data movement completed")
        
         #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_maximus_logs_success_notfound_failed_detailed_logs
        #2.Update Missing RRN in Spice Detail logs from YBL Maximus Txn Report,Validate Spice Detail logs with YBL Maximus Txn Report
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_maximus_logs_success_notfound_failed_detailed_logs data movement started")
        sql_query="""
                select Date , Adjamt , partner_ref_number ,rc as SPICE_LOG_RESP,resp_code as YBL_Response,"Spice" as FileName
        from  
        (
        SELECT date(a.log_date_time) as TRANSDATE,b.jdt_stan as JDT_STAN,a.spice_tid as SPICE_TID,a.client_id as Client_ID
         , (a.trans_amt)as TRANSAMOUNT, b.rc, b.response_message ,a.request_id , b.request_id,  FROM `spicemoney-dwh.prod_dwh.aeps_trans_req` a 
        join `spicemoney-dwh.prod_dwh.aeps_trans_res_v2`b on a.request_id = b.request_id
        WHERE a.aggregator = 'YBLN' and a.master_trans_type = 'CW' and DATE(a.log_date_time) = @date 
        and date(b.log_date_time) = @date 
        ) t1
        right join
        (select date(transaction_date_time) as Date
        ,partner_ref_number,transaction_amt as Adjamt,rrn , resp_code from `spicemoney-dwh.sm_recon.ts_aeps_ybln_transaction_report`
        where date(transaction_date_time) = @date and transaction_type='Withdrawal' and resp_code ='00'
        )t2
        on SPICE_TID = t2.partner_ref_number
        where rc !='00'
        
        """
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_maximus_logs_success_notfound_failed_detailed_logs', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_maximus_logs_success_notfound_failed_detailed_logs', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_maximus_logs_success_notfound_failed_detailed_logs data movement completed")


        #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_maximus_logs_success_notfound_balance_report 
        #3.Validate YBL Maximus Txn Report with Balance summary report
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_maximus_logs_success_notfound_balance_report data movement started")
        sql_query="""
        select RRN,Date,Adjamt,BC_Txn_ID,YBL_Response,Bank_Credit_Amt,Bank_Debit_Amt from 
        (select transaction_type,rrn as RRN , date(transaction_date_time) as Date,transaction_amt as Adjamt,partner_ref_number as BC_Txn_ID,resp_code as YBL_Response
         from `spicemoney-dwh.sm_recon.ts_aeps_ybln_transaction_report`
        where date(transaction_date_time) = @date and resp_code ='00' and transaction_type='Withdrawal')
        LEFT JOIN
        (
        select rrn as Bank_RRN,date(log_txn_time) as Bank_Date,txn_amount as Bank_Adjamt,credit_amt as Bank_Credit_Amt,debit_amt as Bank_Debit_Amt
        from `sm_recon.ts_aeps_ybln_bank_summary` where payment_mode like ("%AEPS%") and date(log_txn_time)=@date
        )
        ON RRN=Bank_RRN
        where Bank_Credit_Amt is null
        """
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_maximus_logs_success_notfound_balance_report', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_maximus_logs_success_notfound_balance_report', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_maximus_logs_success_notfound_balance_report data movement completed")
        
        
         #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_balance_report_success_notfound_failed_ybln_maximus_logs 
        #3.Success in Balance Report not found/Failed in YBL Maximus logs
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_balance_report_success_notfound_failed_ybln_maximus_logs data movement started")
        sql_query="""
        select Bank_RRN,Bank_Date,Bank_Adjamt,YBL_LOG_RRN,YBL_Response,coalesce(Bank_Credit_Amt,0) as Bank_Credit_Amt,Bank_Debit_Amt from 
        (select transaction_type,rrn as YBL_LOG_RRN , date(transaction_date_time) as Date,transaction_amt as Adjamt,partner_ref_number as BC_Txn_ID,resp_code as YBL_Response
         from `spicemoney-dwh.sm_recon.ts_aeps_ybln_transaction_report`
        where date(transaction_date_time) = @date and transaction_type='Withdrawal')
        RIGHT JOIN
        (
        select rrn as Bank_RRN,date(log_txn_time) as Bank_Date,txn_amount as Bank_Adjamt,txn_status,credit_amt as Bank_Credit_Amt,debit_amt as Bank_Debit_Amt
        from `sm_recon.ts_aeps_ybln_bank_summary` where payment_mode like ("%AEPS%") and date(log_txn_time)=@date and txn_status="SUCCESS")
        ON YBL_LOG_RRN=Bank_RRN
        where YBL_Response !='00' or YBL_Response is null
        """
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_balance_report_success_notfound_failed_ybln_maximus_logs', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_balance_report_success_notfound_failed_ybln_maximus_logs', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_balance_report_success_notfound_failed_ybln_maximus_logs data movement completed")
        
        
        
        #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_credit_found_balancerpt_not_threshhold 
        #4 Credit found in Balance report not in Threshold
        #---------------------------------------------------------------------------------------------------------------------
        print("prod_aeps_ybln_credit_found_balancereport_not_threshhold data movement started")

        sql_query="""select Bank_RRN,Bank_Date,Bank_Credit_Amt,Threshhold_RRN from 
        (select rrn as Bank_RRN,date(log_txn_time) as Bank_Date,credit_amt as Bank_Credit_Amt
        from `sm_recon.ts_aeps_ybln_bank_summary` where payment_mode like ("%AEPS%") and date(log_txn_time)=@date)
        LEFT JOIN
        (
        select rrn as Threshhold_RRN,amount,txn_type
        from `sm_recon.ts_aeps_ybln_threshhold_report` where payment_mode like ("%AEPS%") and date(transaction_date)=@date
        and txn_type='CR'
        )
        ON Bank_RRN=Threshhold_RRN
        where Threshhold_RRN is null"""
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_credit_found_balancereport_not_threshhold', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_credit_found_balancereport_not_threshhold', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_credit_found_balancerpt_not_threshhold data movement completed")
        print("prod_aeps_ybln_credit_found_balancereport_not_threshhold data movement completed")
        

        #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_credit_found_threshhold_not_balancerpt 
        #4 #Credit found in Threshold report not in Balance summ
        #---------------------------------------------------------------------------------------------------------------------
        print("prod_aeps_ybln_credit_found_threshhold_not_balance_report data movement started")

        sql_query="""
        select Threshhold_RRN,Threshhold_Date,amount,Bank_Credit_Amt,Bank_RRN from 
        (select rrn as Bank_RRN,date(log_txn_time) as Bank_Date,credit_amt as Bank_Credit_Amt
        from `sm_recon.ts_aeps_ybln_bank_summary` where payment_mode like ("%AEPS%") and date(log_txn_time)=@date)
        RIGHT JOIN
        (
        select rrn as Threshhold_RRN,date(transaction_date) as Threshhold_Date,amount,txn_type
        from `sm_recon.ts_aeps_ybln_threshhold_report` where payment_mode like ("%AEPS%") and date(transaction_date)=@date
        and txn_type='CR'
        )
        ON Bank_RRN=Threshhold_RRN
        where Bank_RRN is null

        """
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_credit_found_threshhold_not_balance_report', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_credit_found_threshhold_not_balance_report', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("ts_aeps_ybln_credit_found_threshhold_not_balance_report data movement completed")
        
        
        #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_debit_found_balancerpt_not_threshhold 
        #4 #Debit found in Threshold report not in Balance summ
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_debit_found_balance_report_not_threshhold data movement started")
        sql_query="""
        select Bank_RRN,Bank_Date,Bank_debit_amt,Threshhold_RRN from 
        (select rrn as Bank_RRN,date(log_txn_time) as Bank_Date,debit_amt as Bank_debit_amt
        from `sm_recon.ts_aeps_ybln_bank_summary` where payment_mode like ("%AEPS%") and date(log_txn_time)=@date)
        LEFT JOIN
        (
        select rrn as Threshhold_RRN,amount,txn_type
        from `sm_recon.ts_aeps_ybln_threshhold_report` where payment_mode like ("%AEPS%") and date(transaction_date)=@date
        and txn_type='DR'
        )
        ON Bank_RRN=Threshhold_RRN
        where Threshhold_RRN is null and Bank_debit_amt!= 0.0

        """
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_debit_found_balance_report_not_threshhold', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_debit_found_balance_report_not_threshhold', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_debit_found_balance_report_not_threshhold data movement completed")
        
         #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_debit_found_threshhold_not_balancerpt 
        #4 #Debit found in Threshold report not in Balance summ
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_debit_found_threshhold_not_balance_report data movement started")
        sql_query=""" 
        select Threshhold_RRN,Threshhold_Date,amount,Bank_RRN from 
        (select rrn as Bank_RRN,date(log_txn_time) as Bank_Date,debit_amt as Bank_debit_amt
        from `sm_recon.ts_aeps_ybln_bank_summary` where payment_mode like ("%AEPS%") and date(log_txn_time)=@date)
        RIGHT JOIN
        (
        select rrn as Threshhold_RRN,date(transaction_date) as Threshhold_Date,amount,txn_type
        from `sm_recon.ts_aeps_ybln_threshhold_report` where payment_mode like ("%AEPS%") and date(transaction_date)=@date
        and txn_type='DR'
        )
        ON Bank_RRN=Threshhold_RRN
        where Bank_RRN is null  and amount!= 0.0
        """
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_debit_found_threshhold_not_balance_report', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_debit_found_threshhold_not_balance_report', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_debit_found_threshhold_not_balance_report data movement completed")
        
        #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_maximus_vs_spice_report_gap 
        #5 #Maximus and Spice report gap
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_maximus_vs_spice_report_gap data movement started")
        sql_query=""" 
        select tran_date_time,partner_ref_number,Maximus_Amount,SPICE_TID,Spice_AMT, Diff from 
        (
        select tran_date_time,partner_ref_number,Maximus_Amount,SPICE_TID,Spice_AMT,(coalesce(Maximus_Amount,0)-coalesce(Spice_AMT,0)) as Diff,rc from 
        (
        select date(transaction_date_time) as tran_date_time, partner_ref_number,sum(transaction_amt) as Maximus_Amount from `spicemoney-dwh.sm_recon.ts_aeps_ybln_transaction_report`
        where date(transaction_date_time) = @date and transaction_type='Withdrawal' and resp_code ='00' group by tran_date_time,partner_ref_number
        )
        LEFT JOIN
        (
        (SELECT date(a.log_date_time) as LOG_DATE_TIME,a.spice_tid as SPICE_TID, sum(a.trans_amt) as Spice_AMT,b.rc
        FROM `spicemoney-dwh.prod_dwh.aeps_trans_req` a
        join
        `spicemoney-dwh.prod_dwh.aeps_trans_res_v2`b
        on a.request_id = b.request_id 
        WHERE date(a.log_date_time)=@date 
            and date(b.log_date_time) = @date and a.master_trans_type = 'CW'  and b.rc="00" and a.aggregator='YBLN'group by LOG_DATE_TIME,SPICE_TID,rc)
        ) as t2
        on SPICE_TID = partner_ref_number)
        where  Diff !=0


        """
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_maximus_vs_spice_report_gap', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_maximus_vs_spice_report_gap', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_maximus_vs_spice_report_gap data movement completed")
        
        #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_spice_report_vs_maximus_gap 
        #5 #Spice report and Maximus gap
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_spice_report_vs_maximus_gap data movement started")
        sql_query=""" 
        select LOG_DATE_TIME,SPICE_TID,Spice_AMT,partner_ref_number,Maximus_Amount, Diff from 
        (
        select LOG_DATE_TIME,SPICE_TID,Spice_AMT,partner_ref_number,Maximus_Amount,(Spice_AMT-Maximus_Amount) as Diff from 
        (
        SELECT date(a.log_date_time) as LOG_DATE_TIME,a.spice_tid as SPICE_TID, sum(a.trans_amt) as Spice_AMT,b.rc
        FROM `spicemoney-dwh.prod_dwh.aeps_trans_req` a
        join
        `spicemoney-dwh.prod_dwh.aeps_trans_res_v2`b
        on a.request_id = b.request_id 
        WHERE date(a.log_date_time)=@date 
            and date(b.log_date_time) = @date and a.master_trans_type = 'CW'  and b.rc="00" and a.aggregator='YBLN'group by LOG_DATE_TIME,SPICE_TID,rc
        )
        LEFT JOIN
        (
        select date(transaction_date_time) as tran_date_time, partner_ref_number,sum(transaction_amt) as Maximus_Amount from `spicemoney-dwh.sm_recon.ts_aeps_ybln_transaction_report`
        where date(transaction_date_time) = @date and transaction_type='Withdrawal' and resp_code ='00' group by tran_date_time,partner_ref_number
        ) as t2
        on SPICE_TID = partner_ref_number)
        where Diff !=0

        """
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_spice_report_vs_maximus_gap', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_spice_report_vs_maximus_gap', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_spice_report_vs_maximus_gap data movement completed")
        
        
        #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_maximus_vs_balance_report_gap 
        #6 #Maximus and Bal Summ report gap
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_maximus_vs_balance_report_gap data movement started")
        sql_query=""" 
       select tran_date_time,rrn as Maximus_RRN,Maximus_Amount,Bal_Summ_RRN,Bal_Summ_Amt, Diff from 
        (
        select tran_date_time,rrn,Maximus_Amount,Bal_Summ_RRN,coalesce(Bal_Summ_Amt,0) as Bal_Summ_Amt,(Maximus_Amount-coalesce(Bal_Summ_Amt,0)) as Diff from 
        (
        select date(transaction_date_time) as tran_date_time, rrn, sum(transaction_amt) as Maximus_Amount from `spicemoney-dwh.sm_recon.ts_aeps_ybln_transaction_report`
        where date(transaction_date_time) = @date and transaction_type='Withdrawal' and resp_code ='00' group by tran_date_time,rrn
        )
        LEFT JOIN
        (select rrn as Bal_Summ_RRN
        ,date(log_txn_time) as Bank_Date,sum(txn_amount) as Bal_Summ_Amt
        from `sm_recon.ts_aeps_ybln_bank_summary` where payment_mode like ("%AEPS%") and date(log_txn_time)=@date
        group by Bal_Summ_RRN,Bank_Date
        ) as t2
        on rrn = Bal_Summ_RRN)
        where Diff !=0


        """
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_maximus_vs_balance_report_gap', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_maximus_vs_balance_report_gap', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_maximus_vs_balance_report_gap data movement completed")
        
        #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_balance_report_vs_maximus_gap 
        #6 #Bal Summ Report and Maximus report Gap
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_balance_report_vs_maximus_gap data movement started")
        sql_query=""" 
        select Bank_Date,Bal_Summ_RRN,Bal_Summ_Amt,rrn as Maximus_RRN,Maximus_Amount,Diff from 
        (
        select Bank_Date,Bal_Summ_RRN,Bal_Summ_Amt,rrn,coalesce(Maximus_Amount,0) as Maximus_Amount,(Bal_Summ_Amt-coalesce(Maximus_Amount,0)) as Diff from 
        (
        select rrn as Bal_Summ_RRN
        ,date(log_txn_time) as Bank_Date,sum(txn_amount) as Bal_Summ_Amt
        from `sm_recon.ts_aeps_ybln_bank_summary` where payment_mode like ("%AEPS%") and date(log_txn_time)=@date
        group by Bal_Summ_RRN,Bank_Date

        )
        LEFT JOIN
        (
        select date(transaction_date_time) as tran_date_time, rrn, sum(transaction_amt) as Maximus_Amount from `spicemoney-dwh.sm_recon.ts_aeps_ybln_transaction_report`
        where date(transaction_date_time) = @date and transaction_type='Withdrawal' and resp_code ='00' group by tran_date_time,rrn
        ) as t2
        on rrn = Bal_Summ_RRN)
        where Diff !=0



        """
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_balance_report_vs_maximus_gap', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_balance_report_vs_maximus_gap', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_balance_report_vs_maximus_gap data movement completed")
        
        #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_threshhold_vs_balance_report_gap 
        #7 #Threshhold and Bal Summ report gap
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_threshhold_vs_balance_report_gap data movement started")
        sql_query=""" 
        select Date,Threshhold_RRN,Threshhold_Amt,Bal_Summ_RRN,Bal_Summ_Amt, Diff from 
        (
        select Date,Threshhold_RRN,coalesce(Threshhold_Amt,0) as Threshhold_Amt ,Bal_Summ_RRN,coalesce(Bal_Summ_Amt,0) as Bal_Summ_Amt,(coalesce(Threshhold_Amt,0)-coalesce(Bal_Summ_Amt,0)) as Diff from 
        (
        select date(transaction_date) as Date, rrn as Threshhold_RRN,sum(amount) as Threshhold_Amt
        from `spicemoney-dwh.sm_recon.ts_aeps_ybln_threshhold_report`
        where date(transaction_date) = @date and payment_mode like ("%AEPS%") and txn_type="CR" group by Date,Threshhold_RRN
        )
        LEFT JOIN
        (select rrn as Bal_Summ_RRN
        ,date(log_txn_time) as Bank_Date,sum(credit_amt) as Bal_Summ_Amt
        from `sm_recon.ts_aeps_ybln_bank_summary` where payment_mode like ("%AEPS%") and date(log_txn_time)=@date
        group by Bal_Summ_RRN,Bank_Date
        ) as t2
        on Threshhold_RRN = Bal_Summ_RRN)
        where Diff !=0
        """
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_threshhold_vs_balance_report_gap', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_threshhold_vs_balance_report_gap', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_threshhold_vs_balance_report_gap data movement completed")
        
         #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_balance_report_vs_threshhold_gap 
        #7 #Bal Summ Report and Threshhold report Gap
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_threshhold_vs_balance_report_gap data movement started")
        sql_query=""" 
        select Bank_Date,Bal_Summ_RRN,Bal_Summ_Amt,Threshhold_RRN,Threshhold_Amt,Diff from 
        (
        select Bank_Date,Bal_Summ_RRN,coalesce(Bal_Summ_Amt,0) as Bal_Summ_Amt,Threshhold_RRN,coalesce(Threshhold_Amt,0) as Threshhold_Amt ,(coalesce(Bal_Summ_Amt,0)-coalesce(Threshhold_Amt,0)) as Diff from 
        (
        select rrn as Bal_Summ_RRN
        ,date(log_txn_time) as Bank_Date,sum(credit_amt) as Bal_Summ_Amt
        from `sm_recon.ts_aeps_ybln_bank_summary` where payment_mode like ("%AEPS%") and date(log_txn_time)=@date 
        group by Bal_Summ_RRN,Bank_Date

        )
        LEFT JOIN
        (
          select date(transaction_date) as Date, rrn as Threshhold_RRN,sum(amount) as Threshhold_Amt
        from `spicemoney-dwh.sm_recon.ts_aeps_ybln_threshhold_report`
        where date(transaction_date) = @date and payment_mode like ("%AEPS%")  and txn_type="CR" group by Date,Threshhold_RRN

        ) as t2
        on Threshhold_RRN = Bal_Summ_RRN)
        where Diff !=0
        """
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_balance_report_vs_threshhold_gap', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_balance_report_vs_threshhold_gap', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_balance_report_vs_threshhold_gap data movement completed")
        
        
        #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_duplicacy_balance_report_debit 
        #---Duplicate in Balance summary report Debit
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_threshhold_vs_balance_report_gap data movement started")
        sql_query=""" 
        select date(log_txn_time) as Date,rrn as Bal_Summ_RRN,count(rrn) as Count_of_Bal_Summ_RRN
        ,credit_amt,debit_amt
        from `sm_recon.ts_aeps_ybln_bank_summary` where payment_mode like ("%AEPS%")  and
        credit_amt=0 and debit_amt!=0
        group by Date,Bal_Summ_RRN,credit_amt,debit_amt
         HAVING Count_of_Bal_Summ_RRN>1
        """
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_duplicacy_balance_report_debit', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_duplicacy_balance_report_debit', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_duplicacy_balance_report_debit data movement completed")

        #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_duplicacy_balance_report_credit 
        #---Duplicate in Balance summary report Credit
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_duplicacy_balance_report_credit data movement started")
        sql_query=""" 
        select date(log_txn_time) as Date,rrn as Bal_Summ_RRN,count(rrn) as Count_of_Bal_Summ_RRN
        ,credit_amt,debit_amt
        from `sm_recon.ts_aeps_ybln_bank_summary` where payment_mode like ("%AEPS%") and date(log_txn_time)=@date and
        credit_amt!=0 and debit_amt=0
        group by Date,Bal_Summ_RRN,credit_amt,debit_amt
         HAVING Count_of_Bal_Summ_RRN>1
        """
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_duplicacy_balance_report_credit', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_duplicacy_balance_report_credit', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_duplicacy_balance_report_credit data movement completed")


        #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_duplicacy_maximus_report 
        #------Duplicate in Maximus report(PUT ON on partner_ref_number)
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_duplicacy_maximus_report data movement started")
        sql_query=""" 
        select date(transaction_date_time) as Date,partner_ref_number,rrn,count(partner_ref_number) as Count_of_partner_ref_number,resp_code
         from `spicemoney-dwh.sm_recon.ts_aeps_ybln_transaction_report`
        where date(transaction_date_time) = @date and resp_code="00" and transaction_type="Withdrawal"
        group by Date,partner_ref_number,rrn,resp_code
         HAVING Count_of_partner_ref_number>1
        """
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_duplicacy_maximus_report', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_duplicacy_maximus_report', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_duplicacy_maximus_report data movement completed")


        #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_duplicacy_spice_detail_log 
        #----------Duplicate in Spice Detail logs_Spice_TID (Overall)
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_duplicacy_spice_detail_log data movement started")
        sql_query=""" 
        SELECT date(a.log_date_time) as LOG_DATE_TIME,a.spice_tid as SPICE_TID,count(a.spice_tid) as Count_of_spice_TID
        FROM `spicemoney-dwh.prod_dwh.aeps_trans_req` a
        join
        `spicemoney-dwh.prod_dwh.aeps_trans_res_v2`b
        on a.request_id = b.request_id 
        WHERE date(a.log_date_time)=@date 
            and date(b.log_date_time) = @date and 
            b.rc = '00' and a.master_trans_type = 'CW'  and a.aggregator='YBLN'
            group by LOG_DATE_TIME,SPICE_TID
         HAVING Count_of_spice_TID>1
        """
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_duplicacy_spice_detail_log', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_duplicacy_spice_detail_log', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_duplicacy_spice_detail_log data movement completed")



        #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_duplicacy_spice_detail_log_jdtstan 
        #------Duplicate in Spice Detail logs_JDT_STAN
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_duplicacy_spice_detail_log_jdtstan data movement started")
        sql_query=""" 
        SELECT date(a.log_date_time) as LOG_DATE_TIME,b.jdt_stan as Jdt_Stan,count(b.jdt_stan) as Count_of_jdt_stan,
        FROM `spicemoney-dwh.prod_dwh.aeps_trans_req` a
        join
        `spicemoney-dwh.prod_dwh.aeps_trans_res_v2`b
        on a.request_id = b.request_id 
        WHERE date(a.log_date_time)=@date 
            and date(b.log_date_time) = @date and 
            b.rc = '00' and a.master_trans_type = 'CW'  and a.aggregator='YBLN'
            group by LOG_DATE_TIME,Jdt_Stan
         HAVING Count_of_jdt_stan>1
        """
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_duplicacy_spice_detail_log_jdtstan', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_duplicacy_spice_detail_log_jdtstan', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_duplicacy_spice_detail_log_jdtstan data movement completed")


        #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_credit_adjustment_format 
        #-#Credit adjustment Format
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_credit_adjustment_format data movement started")
        sql_query=""" 
        select TRANSDATE , rrn ,SPICE_LOG_RESP, SPICE_TID ,partner_ref_number,YBLBCRETAILERID,Trans_Amount,NPCIRESPONSECODE
        from  
        (
        SELECT date(a.log_date_time) as TRANSDATE,request_rrn,a.spice_tid as SPICE_TID,b.rc as SPICE_LOG_RESP 
         FROM `spicemoney-dwh.prod_dwh.aeps_trans_req` a 
        join `spicemoney-dwh.prod_dwh.aeps_trans_res_v2`b on a.request_id = b.request_id
        WHERE a.aggregator = 'YBLN' and a.master_trans_type = 'CW' and DATE(a.log_date_time) = @date 
        and date(b.log_date_time) = @date 
        ) t1
        right join
        (select date(transaction_date_time) as Date,
        partner_ref_number,transaction_amt as Adjamt,rrn,resp_code,
        agent_id as YBLBCRETAILERID,transaction_amt as Trans_Amount,resp_code as NPCIRESPONSECODE
        from `spicemoney-dwh.sm_recon.ts_aeps_ybln_transaction_report`
        where date(transaction_date_time) = @date and transaction_type='Withdrawal' and resp_code ='00'
        )t2
        on SPICE_TID = t2.partner_ref_number
        where SPICE_LOG_RESP !='00'
        """
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_credit_adjustment_format', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_credit_adjustment_format', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_credit_adjustment_format data movement completed")



        #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_limit_mtd_min_max 
        #-#prod_aeps_ybln_limit_mtd_min_max
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_limit_mtd_min_max data movement started")
        sql_query=""" 
        select (@date) as recon_date,* from(

        select Min_Amount_Transaction_Id as TransId,MIN_TRANSACTION_AMOUNT as Amount,"MIN" as Type from 
        (
         select spice_tid as Min_Amount_Transaction_Id,trans_amt as MIN_TRANSACTION_AMOUNT from
         (
            select *  
            from `spicemoney-dwh.prod_dwh.aeps_trans_req` a  
                join `spicemoney-dwh.prod_dwh.aeps_trans_res_v2` b 
                on a.request_id=b.request_id 
                where date(a.log_date_time) =@date
                and b.rc='00'  and date(b.log_date_time)=@date
                and a.aggregator='YBLN' and master_trans_type='CW'
         )
          where trans_amt=(select MIN(trans_amt)  from `spicemoney-dwh.prod_dwh.aeps_trans_req` a  
                join `spicemoney-dwh.prod_dwh.aeps_trans_res_v2` b 
                on a.request_id=b.request_id 
                where date(a.log_date_time) =@date
                and b.rc='00'  and date(b.log_date_time)=@date
                and a.aggregator='YBLN' and master_trans_type='CW') limit 1
        )
        UNION ALL
        (
         select TransId,Amount,"MAX" as Type from 
        (
         select spice_tid as TransId,trans_amt as Amount from
         (
            select *  
            from `spicemoney-dwh.prod_dwh.aeps_trans_req` a  
                join `spicemoney-dwh.prod_dwh.aeps_trans_res_v2` b 
                on a.request_id=b.request_id 
                where date(a.log_date_time) =@date
                and b.rc='00'  and date(b.log_date_time)=@date
                and a.aggregator='YBLN' and master_trans_type='CW'
         )
          where trans_amt=(select MAX(trans_amt)  from `spicemoney-dwh.prod_dwh.aeps_trans_req` a  
                join `spicemoney-dwh.prod_dwh.aeps_trans_res_v2` b 
                on a.request_id=b.request_id 
                where date(a.log_date_time) =@date
                and b.rc='00'  and date(b.log_date_time)=@date
                and a.aggregator='YBLN' and master_trans_type='CW') limit 1
        )
        )
        )
        """
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_limit_mtd_min_max', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_limit_mtd_min_max', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_limit_mtd_min_max data movement completed")
        

        #---------------------------------------------------------------------------------------------------------------------
        #-prod_aeps_ybln_recon_tracker
        #-#RECON TRACKER
        #---------------------------------------------------------------------------------------------------------------------
        
        print("prod_aeps_ybln_recon_tracker data movement started")
        sql_query=""" select Date,Txn_Count_As_Per_Detailed_Logs,Total_Amount_Eligible_For_SDL_Payout, round(sdl_Share,2) as sdl_Share,SDL_Share_with_gst,AEPS_Alliance_Transaction_Commission,AEPS_Sub_Distr_Transaction_Commission,AEPS_Agent_Transaction_Commission,AEPS_Distr_Transaction_Commission,AEPS_CW_Partner_Commission,AEPS_CW_Super_Partner_Commission, Total_Commission_Credited,Agent_Wallet_Credit_Amount_FTR,Amt_As_Per_Details_Logs_SDL,Diff_FTR_vs_SDL_Logs ,Amt_As_Per_YBLN_Recon_File,Amt_As_Per_Threshold_Report,Amt_As_Per_Bank_Summary_Report,Diff_Threshold_Logs_vs_Bal_Summ,Diff_YBLN_Logs_vs_Soar_Wallet,
        Diff_Spice_logs_vs_Soar_Wallet,Diff_YBLN_Logs_vs_Spice_logs ,Amt_As_Per_Bank_Statement_DR_CR_Adjustments_Processed, 
        (Diff_Spice_logs_vs_Soar_Wallet-Amt_As_Per_Bank_Statement_DR_CR_Adjustments_Processed) as  Diff_BW_SDL_vs_YBLN_After_Adjustments,
        Total_Amount_Eligible_For_SDL_Payout as Total_Amount_Eligible_For_SDL_Payout_1, round(SDL_Share_CD_CW,2) as SDL_Share_CD_CW,round(TDS_Deduction,2) as TDS_Deduction ,SDL_Share_with_gst as SDL_Share_With_GST_1,round(Settlement_Charges_To_Be_Cr_By_YBLN,2) as Settlement_Charges_To_Be_Cr_By_YBLN,round(Ten_Percen_Of_Settlement_Hold_By_YBLN,2) as Ten_Percen_Of_Settlement_Hold_By_YBLN,
        round((Settlement_Charges_To_Be_Cr_By_YBLN-Ten_Percen_Of_Settlement_Hold_By_YBLN)+
        (Net_Credit_By_YBLN_on_Recon_Date-TDS_on_Income_5_percent),2) as Net_Income_Credited_As_On_Date,
        Amt_Credited_As_Per_Bank_Statement,round(GST_On_Settlement,2) as GST_On_Settlement,
        round((Settlement_Charges_To_Be_Cr_By_YBLN+GST_On_Settlement+SDL_Income_with_GST)-(Amt_Credited_As_Per_Bank_Statement),2)as Diff_SDL_vs_Bank_Statement_Income_GST,round(Mini_Statement_Txn_Count_As_Per_YBLN,2) as Mini_Statement_Txn_Count_As_Per_YBLN,
        round(TDS_on_Income_5_percent,2) as TDS_on_Income_5_percent,Mini_Statement_Income,
        round(Min_ST_10_Percent_Hold_By_YBLN,2) as Min_ST_10_Percent_Hold_By_YBLN,
        round(Net_Credit_By_YBLN_on_Recon_Date,2) as Net_Credit_By_YBLN_on_Recon_Date,
        round(GST_on_Income,2) as GST_on_Income,
        round(SDL_Income_with_GST,2) as SDL_Income_with_GST,
        Mini_Statement_Txn_Count_As_Per_Spice,Diff_Spice_Vs_YBLN_Count
        from 
        (
          select Date,Txn_Count_As_Per_Detailed_Logs,Total_Amount_Eligible_For_SDL_Payout, sdl_Share,round((1.18*sdl_Share),2) as SDL_Share_with_gst,AEPS_Alliance_Transaction_Commission,AEPS_Sub_Distr_Transaction_Commission,AEPS_Agent_Transaction_Commission,AEPS_Distr_Transaction_Commission,AEPS_CW_Partner_Commission,AEPS_CW_Super_Partner_Commission, Total_Commission_Credited,Agent_Wallet_Credit_Amount_FTR,Amt_As_Per_Details_Logs_SDL,coalesce(Agent_Wallet_Credit_Amount_FTR)-coalesce(Amt_As_Per_Details_Logs_SDL) as Diff_FTR_vs_SDL_Logs ,Amt_As_Per_YBLN_Recon_File,Amt_As_Per_Threshold_Report,Amt_As_Per_Bank_Summary_Report, 
        coalesce(Amt_As_Per_Threshold_Report,0)-coalesce(Amt_As_Per_Bank_Summary_Report,0) as  
        Diff_Threshold_Logs_vs_Bal_Summ,
        coalesce(Amt_As_Per_YBLN_Recon_File,0)-coalesce(Amt_As_Per_Bank_Summary_Report,0) as Diff_YBLN_Logs_vs_Soar_Wallet,
        coalesce(Amt_As_Per_Bank_Summary_Report,0)-coalesce(Amt_As_Per_Details_Logs_SDL,0) as Diff_Spice_logs_vs_Soar_Wallet, 
        coalesce(Amt_As_Per_YBLN_Recon_File,0)-coalesce(Amt_As_Per_Details_Logs_SDL,0) as Diff_YBLN_Logs_vs_Spice_logs ,
        Amt_As_Per_Bank_Statement_DR_CR_Adjustments_Processed,
        Amt_Credited_As_Per_Bank_Statement ,
        sdl_Share as SDL_Share_CD_CW,
        (0.05*sdl_Share) as TDS_Deduction,(sdl_Share-0.05*sdl_Share) as Settlement_Charges_To_Be_Cr_By_YBLN,
        (0.1*(sdl_Share-0.05*sdl_Share)) as  Ten_Percen_Of_Settlement_Hold_By_YBLN,
        ((1.18*sdl_Share)-sdl_Share) as  GST_On_Settlement,
        Mini_Statement_Txn_Count_As_Per_YBLN,
        Mini_Statement_Txn_Count_As_Per_YBLN*2.85 as Mini_Statement_Income,
        0.05*(Mini_Statement_Txn_Count_As_Per_YBLN*2.85 ) as TDS_on_Income_5_percent,
        0.1*(Mini_Statement_Txn_Count_As_Per_YBLN*2.85 ) as Min_ST_10_Percent_Hold_By_YBLN,
        (Mini_Statement_Txn_Count_As_Per_YBLN*2.85)-(0.1*(Mini_Statement_Txn_Count_As_Per_YBLN*2.85)) as Net_Credit_By_YBLN_on_Recon_Date,
        0.18*(Mini_Statement_Txn_Count_As_Per_YBLN*2.85) as GST_on_Income,
        (Mini_Statement_Txn_Count_As_Per_YBLN*2.85)+(0.18*(Mini_Statement_Txn_Count_As_Per_YBLN*2.85))-(0.05*(Mini_Statement_Txn_Count_As_Per_YBLN*2.85 )) as SDL_Income_with_GST,Mini_Statement_Txn_Count_As_Per_Spice,
        Mini_Statement_Txn_Count_As_Per_YBLN-Mini_Statement_Txn_Count_As_Per_Spice as 
        Diff_Spice_Vs_YBLN_Count
        from 
        (
        SELECT DATE(a.log_date_time) AS Date,count(*) as  Txn_Count_As_Per_Detailed_Logs, 
        CAST(SUM(CASE
                  WHEN trans_amt*0.005>15 THEN 15
                ELSE
                trans_amt*0.005
              END
                ) AS int64) AS Total_Amount_Eligible_For_SDL_Payout,
        FROM `spicemoney-dwh.prod_dwh.aeps_trans_req` a
        join
        `spicemoney-dwh.prod_dwh.aeps_trans_res_v2`b
        on a.request_id = b.request_id 
        WHERE date(a.log_date_time)=@date 
        and date(b.log_date_time) = @date and 
        b.rc = '00' and a.master_trans_type = 'CW'  and a.aggregator='YBLN' group by Date) as A_E,
        (
        select SUM(Bank_spice_Share-Bank_Share) as sdl_Share from 
        (SELECT spice_tid,DATE(a.log_date_time) AS Date,trans_amt,

        (CASE
                  WHEN trans_amt*0.005>15 THEN 15
                ELSE
                trans_amt*0.005
              END
                ) as Bank_spice_Share,
                (CASE WHEN 
                (CASE
                   WHEN trans_amt*0.005>15 THEN 15
                ELSE
                trans_amt*0.005
              END
                )* 0.05 < 0.15 THEN 0.15
                ELSE 
                 (CASE
                   WHEN trans_amt*0.005>15 THEN 15
                ELSE
                trans_amt*0.005
              END
                )* 0.05 END )
                as Bank_Share
        FROM `spicemoney-dwh.prod_dwh.aeps_trans_req` a
        join
        `spicemoney-dwh.prod_dwh.aeps_trans_res_v2`b
        on a.request_id = b.request_id 
        WHERE date(a.log_date_time)=@date 
        and date(b.log_date_time) = @date and 
        b.rc = '00' and a.master_trans_type = 'CW'  and a.aggregator='YBLN')
        ) as D,
        (SELECT DATE(transfer_date) AS cme_date,
            CAST(SUM(CASE
                  WHEN comments = 'AEPS RBL Alliance Transaction Commission' THEN amount_transferred
                ELSE
                0
              END
                ) AS int64) AS  AEPS_Alliance_Transaction_Commission ,
             CAST(SUM(CASE
                  WHEN comments = 'AEPS RBL Sub Distr Transaction Commission' THEN amount_transferred
                ELSE
                0
              END
                ) AS int64) AS  AEPS_Sub_Distr_Transaction_Commission ,
            CAST(SUM(CASE
                  WHEN comments = 'AEPS RBL Transaction Commission' THEN amount_transferred
                ELSE
                0
              END
                ) AS int64) AS  AEPS_Agent_Transaction_Commission 
        ,
            CAST(SUM(CASE
                  WHEN comments = 'AEPS RBL Distr Transaction Commission' OR comments = 'AEPS-CW Dist Commission' THEN amount_transferred
                ELSE
                0
              END
                ) AS int64) AS  AEPS_Distr_Transaction_Commission 
            ,CAST(SUM(CASE
                  WHEN comments = 'AEPS-CW Partner Commission' THEN amount_transferred
                ELSE
                0
              END
                ) AS int64) AS AEPS_CW_Partner_Commission,
            CAST(SUM(CASE
                  WHEN comments = 'AEPS-CW Super Partner Commission' THEN amount_transferred
                ELSE
                0
              END
                ) AS int64) AS AEPS_CW_Super_Partner_Commission,
                CAST(SUM(CASE
                  WHEN comments = 'AEPS RBL Alliance Transaction Commission' THEN amount_transferred
                ELSE
                0
              END
                ) AS int64)+ CAST(SUM(CASE
                  WHEN comments = 'AEPS RBL Transaction Commission' THEN amount_transferred
                ELSE
                0
              END
                ) AS int64)+ CAST(SUM(CASE
                  WHEN comments = 'AEPS RBL Distr Transaction Commission' OR comments = 'AEPS-CW Dist Commission' THEN amount_transferred
                ELSE
                0
              END
                ) AS int64)+ CAST(SUM(CASE
                  WHEN comments = 'AEPS RBL Sub Distr Transaction Commission' THEN amount_transferred
                ELSE
                0
              END
                ) AS int64)+ CAST(SUM(CASE
                  WHEN comments = 'AEPS-CW Partner Commission' THEN amount_transferred
                ELSE
                0
              END
                ) AS int64)+CAST(SUM(CASE
                  WHEN comments = 'AEPS-CW Super Partner Commission' THEN amount_transferred
                ELSE
                0
              END
                ) AS int64) AS Total_Commission_Credited,
            CAST(SUM(CASE
                  WHEN comments = 'AEPS RBL- Cash Withdrawal' OR comments = ' AEPS-CASH WITHDRAWAL-MANUAL-CREDIT' THEN amount_transferred
                ELSE
                0
              END
                ) AS int64) AS  Agent_Wallet_Credit_Amount_FTR 
          FROM
            `spicemoney-dwh.prod_dwh.cme_wallet` a
          JOIN (
            SELECT
              SPICE_TID
            FROM
              spicemoney-dwh.prod_dwh.aeps_trans_req a
            JOIN
              spicemoney-dwh.prod_dwh.aeps_trans_res_v2 b
            ON
              a.request_id=b.request_id
            WHERE
              DATE(a.log_date_time) =@date
              AND b.rc='00'
              AND DATE(b.log_date_time)=@date
              AND a.aggregator='YBLN'
              AND master_trans_type='CW' ) AS b
          ON
            a.unique_identification_no = b.spice_tid
          WHERE
            DATE(transfer_date)=@date
          GROUP BY
            cme_date 

        ) as F_M,
        (
          SELECT
            DATE(a.log_date_time) AS sld_log_date,
            SUM(trans_amt) AS Amt_As_Per_Details_Logs_SDL
          FROM
            `spicemoney-dwh.prod_dwh.aeps_trans_req` a
          JOIN
            `spicemoney-dwh.prod_dwh.aeps_trans_res_v2` b
          ON
            a.request_id=b.request_id
          WHERE
            DATE(a.log_date_time) =@date
            AND b.rc='00'
            AND DATE(b.log_date_time)=@date
            AND a.aggregator='YBLN'
            AND master_trans_type='CW'
          GROUP BY sld_log_date
        ) as N,
        (
        select sum(transaction_amt) as  Amt_As_Per_YBLN_Recon_File 
         from `spicemoney-dwh.sm_recon.ts_aeps_ybln_transaction_report`
        where date(transaction_date_time) = @date and transaction_type='Withdrawal' and resp_code="00" ) as P,
        (
        select sum(amount) as  Amt_As_Per_Threshold_Report 
        from `sm_recon.ts_aeps_ybln_threshhold_report` where payment_mode like ("%AEPS%") and date(transaction_date)=@date

        )as Q,
        (
        select sum(txn_amount) as  Amt_As_Per_Bank_Summary_Report
        from `sm_recon.ts_aeps_ybln_bank_summary` where payment_mode like ("%AEPS%") and date(log_txn_time)=@date)
        as R,
        (
          select coalesce((
          select ABS(amount) as Amt_As_Per_Bank_Statement_DR_CR_Adjustments_Processed 
          from `sm_recon.ts_aeps_ybln_bank_settlement` where date(txn_date)=@date 
          and narration like("%YAU%") and DRCR_FLAG="D"),0) as Amt_As_Per_Bank_Statement_DR_CR_Adjustments_Processed

        ) as W,
        (
          select coalesce((
          select t1.amount+t2.amount as Amt_Credited_As_Per_Bank_Statement from
        (select amount from `sm_recon.ts_aeps_ybln_bank_settlement` where date(txn_date)=@date 
        and 
        narration like ("%AEPS MS COM:SPICE DIGITAL:YAU DT%")
        and DRCR_FLAG="C") as t1,
        (
        select amount from `sm_recon.ts_aeps_ybln_bank_settlement` where date(txn_date)=@date 
        and 
        narration like ("%AEPS BC COM:SPICE DIGITAL:YAU DT%")
        and DRCR_FLAG="C") as t2

        ),0)as Amt_Credited_As_Per_Bank_Statement) as XX,
        (
          select count(transaction_amt)  as Mini_Statement_Txn_Count_As_Per_YBLN
         from `spicemoney-dwh.sm_recon.ts_aeps_ybln_transaction_report`
        where date(transaction_date_time) = @date and transaction_type='MiniStatement' and resp_code="00" 
        ) as S,
        (
         select count(*) as Mini_Statement_Txn_Count_As_Per_Spice
         FROM `spicemoney-dwh.prod_dwh.aeps_trans_req` a
        join
        `spicemoney-dwh.prod_dwh.aeps_trans_res_v2`b
        on a.request_id = b.request_id 
        WHERE date(a.log_date_time)=@date 
        and date(b.log_date_time) = @date and 
        b.rc = '00' and a.master_trans_type = 'MS'  and a.aggregator='YBLN'

        )

        )
        """
    
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.ts_aeps_ybln_recon_tracker', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_aeps_ybln_recon_tracker', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("prod_aeps_ybln_recon_tracker data movement completed")

        print("---------------------------------------------------------------")
		
	   
        print('Recon Success for {} at {}'.format(dates, times))
        with open('/home/sdlreco/crons/aeps_ybln/stat/stat-'+str(dates)+'.txt', 'w') as f:
            f.write('1')
            f.close()

	#driver

import sys
sys.path.insert(0, '/home/sdlreco/crons/smarten/')
import payload as smarten

aeps_ybln = ['1841809ca54.dtst','1841846bd6a.dtst','184184fd6dd.dtst','1841867a949.dtst','184186ba7dd.dtst','1841871b10c.dtst','18418764250.dtst','184187db941.dtst','18418c7eb0e.dtst','18418cc4dc2.dtst','18418d01753.dtst','18418d3bd89.dtst','18418d7387c.dtst','18418dc675f.dtst','18418df51a2.dtst','18418e1adb0.dtst','1841cf2e87d.dtst','1841cf671d7.dtst','1841cf9f847.dtst','1841cfc5b70.dtst','1841cfe74e7.dtst','1841d012b01.dtst','1841d538135.dtst']

with open('/home/sdlreco/crons/aeps_ybln/stat/stat-'+str(dates)+'.txt', 'r') as f:
    lines = f.read().splitlines()
    f.close()
if('1' in lines):
    print('Tried at {}, but reco already done !!'.format(times))
else:
    main()
    for ids in aeps_ybln:

        smarten.payload(ids)
    print('Refreshed : aeps_ybln')
