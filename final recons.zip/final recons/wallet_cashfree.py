import numpy as np
import pandas as pd
import fsspec
from google.cloud import bigquery
from datetime import datetime
from datetime import date as d
import os
from google.oauth2 import service_account
from google.cloud import storage
from datetime import timedelta
import warnings

warnings.filterwarnings('ignore', category=UserWarning, module='openpyxl')

dates = d.today()
times = datetime.now()

f = open('/home/sdlreco/crons/wallet_cashfree/stat/stat-'+str(dates)+'.txt', 'a+')
f.close()

fa=open('/home/sdlreco/crons/wallet_cashfree/error/missing-'+str(dates)+'.txt', 'w')
fa.close()


# key_path='C:/Users/roop.sidhu_spicemone/Downloads/roop-sidhu.json'

def main():
    
    current_date = d.today()-timedelta(1)

    date = d.today()
    current_year = date.strftime('%Y')

    date = d.today()
    current_month = date.strftime('%m')

    date = d.today()

    current_day = date.strftime('%d')
    
    date = d.today()-timedelta(1)
    previous_day = date.strftime('%d')
    
    date = d.today()
    current_mon = date.strftime('%b')
    
    date = d.today()
    current_yr = date.strftime('%y')
    

    
    project_id = 'spicemoney-dwh'

    client = bigquery.Client(project=project_id, location='asia-south1')

    file_exists = []
    try:
        pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/CashFreePaymentsTransactions Report/Transaction Report '+str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)  +' - '+ str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)+'.csv')
        file_exists.append(True)

    except:
        file_exists.append(False) 
        
        with open('/home/sdlreco/crons/wallet_cashfree/error/missing-'+str(dates)+'.txt', 'a+') as f:
            f.write(str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/CashFreePaymentsTransactions Report/Transaction Report '+str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)  +' - '+ str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)+'.csv')
            f.write('\n')
    
    try:
        #pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/CashFreePaymentsSettlement Recon Report/Settlement Recon Report '+str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)  +' - '+ str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)+'.csv')
        pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/CashFreePaymentsSettlement Recon Report/Settlement Recon Report '+str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)  +' - '+ str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)+'.csv', nrows=1,skiprows=1)

        file_exists.append(True)
        # sm-prod-rpa/2022/08/30/CashFreePaymentsSettlementReport/Settlement Summary Report 29 Aug 2022 - 29 Aug 2022.csv
    except:
        file_exists.append(False) 
        
        with open('/home/sdlreco/crons/wallet_cashfree/error/missing-'+str(dates)+'.txt', 'a+') as f:
            f.write('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/CashFreePaymentsSettlement Recon Report/Settlement Recon Report '+str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)  +' - '+ str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)+'.csv')

            f.write('\n')

    try:
        #pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/CashFreePaymentsSettlement Recon Report/Settlement Recon Report '+str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)  +' - '+ str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)+'.csv')
        pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/CashFreePaymentsPayment Link Transactions Report/Payment Link Transactions Report '+str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)  +' - '+ str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)+'/Payment-Link-Transactions-Report-'+str(previous_day)+'-'+ str(current_mon)+'-'+str(current_year) +'---'+ str(previous_day)+'-'+ str(current_mon)+'-'+str(current_year)+'*.csv')

        file_exists.append(True)
        # sm-prod-rpa/2022/08/30/CashFreePaymentsSettlementReport/Settlement Summary Report 29 Aug 2022 - 29 Aug 2022.csv
    except:
        file_exists.append(False) 
        
        with open('/home/sdlreco/crons/wallet_cashfree/error/missing-'+str(dates)+'.txt', 'a+') as f:
            f.write('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/CashFreePaymentsPayment Link Transactions Report/Payment Link Transactions Report '+str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)  +' - '+ str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)+'/Payment-Link-Transactions-Report-'+str(previous_day)+'-'+ str(current_mon)+'-'+str(current_year) +'---'+ str(previous_day)+'-'+ str(current_mon)+'-'+str(current_year)+'*.csv')

            f.write('\n')

    
    if False in file_exists:
        print('Files missing : Logged at -- /home/sdlreco/crons/wallet_cashfree/error/missing-'+str(dates)+'.txt')
    else:
   
        #CashFreePaymentsTransactionReport File
        print("CashFreePaymentsTransactionReport file loading started")
        schema=[{'name':'order_id','type':'STRING'},
                {'name':'reference_id','type':'STRING'},
                {'name':'customer_name','type':'STRING'},
                {'name':'customer_phone','type':'STRING'},
                {'name':'customer_email','type':'STRING'},
                {'name':'order_note','type':'STRING'},
                {'name':'currency','type':'STRING'},
                {'name':'amount','type':'FLOAT'},
                {'name':'service_charge','type':'FLOAT'},
                {'name':'st_gst','type':'FLOAT'},
                {'name':'settlement_amount','type':'FLOAT'},
                {'name':'payment_mode','type':'STRING'},
                {'name':'bank_name','type':'STRING'},
                {'name':'card_scheme','type':'STRING'},
                {'name':'bank_reference_no','type':'STRING'},
                {'name':'card_number','type':'STRING'},
                {'name':'card_country','type':'STRING'},
                {'name':'transaction_time','type':'TIMESTAMP'},
                {'name':'transaction_status','type':'STRING'},
                {'name':'settlement','type':'STRING'},
                {'name':'utr_no','type':'STRING'},
                {'name':'settled_on','type':'TIMESTAMP'},
                {'name':'refunded','type':'STRING'},
                {'name':'customer_reference_id','type':'STRING'},
                {'name':'surcharge_amount','type':'FLOAT'}   
                
        ]
        
                  
        header_list = ['order_id',
                        'reference_id',
                        'customer_name',
                        'customer_phone',
                        'customer_email',
                        'order_note',
                        'currency',
                        'amount',
                        'service_charge',
                        'st_gst',
                        'settlement_amount',
                        'payment_mode',
                        'bank_name',
                        'card_scheme',
                        'bank_reference_no',
                        'card_number',
                        'card_country',
                        'transaction_time',
                        'transaction_status',
                        'settlement',
                        'utr_no',
                        'settled_on',
                        'refunded',
                        'customer_reference_id',
                        'surcharge_amount']
        
        list1= ['order_id',
                'reference_id',
                'customer_name',
                'customer_phone',
                'customer_email',
                'order_note',
                'currency',
                'payment_mode',
                'bank_name',
                'card_scheme',
                'bank_reference_no',
                'card_number',
                'card_country',
                'transaction_status',
                'settlement',
                'utr_no',
                'refunded',
                'customer_reference_id']
        
        list2=['amount',
                'service_charge',
                'st_gst',
                'settlement_amount',
                'surcharge_amount']
        print('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/CashFreePaymentsTransactions Report/Transaction Report '+str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)  +' - '+ str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)+'.csv')
        df = pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/CashFreePaymentsTransactions Report/Transaction Report '+str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)  +' - '+ str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)+'.csv', skiprows=1, names=header_list, parse_dates = (['transaction_time','settled_on']), low_memory=False)
        
        
        df[list1]=df[list1].astype(str)
        df[list2]=df[list2].astype(float)
        
        
        df.to_gbq(destination_table='sm_recon.wallet_cashfree_detail_log', project_id='spicemoney-dwh', if_exists='replace' , table_schema = schema)
        df.to_gbq(destination_table='prod_sm_recon.prod_wallet_cashfree_detail_log', project_id='spicemoney-dwh', if_exists='append' , table_schema = schema)
        print("CashFreePaymentsTransactionReport file loading completed")
        print("-----------------------------------------------------------")


        ###############################################################################
        #Payment Link file
        ###############################################################################
        print("PaymentLink file loading started")
        
        payment_schema=[{'name':'cf_link_id','type':'STRING'},
                {'name':'link_id','type':'STRING'},
                {'name':'order_id','type':'STRING'},
                {'name':'reference_id','type':'STRING'},
                {'name':'customer_name','type':'STRING'},
                {'name':'customer_phone','type':'STRING'},
                {'name':'customer_email','type':'STRING'},
                {'name':'description','type':'STRING'},
                {'name':'order_note','type':'STRING'},
                {'name':'currency','type':'STRING'},
                {'name':'amount','type':'FLOAT'},
                {'name':'service_charge','type':'FLOAT'},
                {'name':'st_gst','type':'FLOAT'},
                {'name':'settlement_amount','type':'FLOAT'},
                {'name':'payment_mode','type':'STRING'},
                {'name':'bank_name','type':'STRING'},
                {'name':'card_scheme','type':'STRING'},
                {'name':'card_number','type':'STRING'},
                {'name':'card_country','type':'STRING'},
                {'name':'transaction_time','type':'DATETIME'},
                {'name':'transaction_status','type':'STRING'},
                {'name':'settlement','type':'STRING'},
                {'name':'utr_no','type':'STRING'},
                {'name':'settled_on','type':'TIMESTAMP'},
                {'name':'refunded','type':'STRING'},
                {'name':'notes1_Key','type':'STRING'},
                {'name':'notes1_Value','type':'STRING'},
                {'name':'notes2_Key','type':'STRING'},
                {'name':'notes2_Value','type':'STRING'},
                {'name':'notes3_Key','type':'STRING'},
                {'name':'notes3_Value','type':'STRING'},
                {'name':'notes4_Key','type':'STRING'},
                {'name':'notes4_Value','type':'STRING'},
                {'name':'notes5_Key','type':'STRING'},
                {'name':'notes5_Value','type':'STRING'}]
        
            #Specifying the header column            
        payment_header_list = ['cf_link_id',
                            'link_id',
                            'order_id',
                            'reference_id',
                            'customer_name',
                            'customer_phone',
                            'customer_email',
                            'description',
                            'order_note',
                            'currency',
                            'amount',
                            'service_charge',
                            'st_gst',
                            'settlement_amount',
                            'payment_mode',
                            'bank_name',
                            'card_scheme',
                            'card_number',
                            'card_country',
                            'transaction_time',
                            'transaction_status',
                            'settlement',
                            'utr_no',
                            'settled_on',
                            'refunded',
                            'notes1_Key',
                            'notes1_Value',
                            'notes2_Key',
                            'notes2_Value',
                            'notes3_Key',
                            'notes3_Value',
                            'notes4_Key',
                            'notes4_Value',
                            'notes5_Key',
                            'notes5_Value']
            
        payment_list1= ['cf_link_id',
                    'link_id',
                    'order_id',
                    'reference_id',
                    'customer_name',
                    'customer_phone',
                    'customer_email',
                    'description',
                    'order_note',
                    'currency',
                    'payment_mode',
                    'bank_name',
                    'card_scheme',
                    'card_number',
                    'card_country',
                    'transaction_status',
                    'settlement',
                    'utr_no',
                    'refunded',
                    'notes1_Key',
                    'notes1_Value',
                    'notes2_Key',
                    'notes2_Value',
                    'notes3_Key',
                    'notes3_Value',
                    'notes4_Key',
                    'notes4_Value',
                    'notes5_Key',
                    'notes5_Value']
            
        payment_list2=['amount',
                    'service_charge',
                    'st_gst',
                    'settlement_amount']
        print('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/CashFreePaymentsPayment Link Transactions Report/Payment Link Transactions Report '+str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)  +' - '+ str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)+'/Payment-Link-Transactions-Report-'+str(previous_day)+'-'+ str(current_mon)+'-'+str(current_year) +'---'+ str(previous_day)+'-'+ str(current_mon)+'-'+str(current_year)+'*.csv')
        payment_df = pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/CashFreePaymentsPayment Link Transactions Report/Payment Link Transactions Report '+str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)  +' - '+ str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)+'/Payment-Link-Transactions-Report-'+str(previous_day)+'-'+ str(current_mon)+'-'+str(current_year) +'---'+ str(previous_day)+'-'+ str(current_mon)+'-'+str(current_year)+'*.csv', skiprows=1, names=payment_header_list, parse_dates = (['settled_on']))
        print(payment_df['transaction_time'])
        payment_df[payment_list1]=payment_df[payment_list1].astype(str)
        payment_df[payment_list2]=payment_df[payment_list2].astype(float)
        payment_df['transaction_time'] = pd.to_datetime(payment_df['transaction_time'])
        print(payment_df['transaction_time']) 
        #payment_df['transaction_time']=pd.to_datetime(payment_df['transaction_time'].dt.strftime('%Y-%d-%m %H:%M:%S'))
            
        payment_df.to_gbq(destination_table='sm_recon.wallet_cashfree_payment_link_transactions_log', project_id='spicemoney-dwh', if_exists='replace' , table_schema = payment_schema)
        payment_df.to_gbq(destination_table='prod_sm_recon.prod_wallet_cashfree_payment_link_transactions_log', project_id='spicemoney-dwh', if_exists='append' , table_schema = payment_schema)
        print("PaymentLinkFile loading completed")
        print("-----------------------------------------------------------")
        
        ###########################################################################################
        #SummarySchema
        ########################################################################################### 
        print("Summary file Upper part loading started")
              
        upper_schema=[{'name':'Id','type':'STRING'},
                {'name':'total_transaction_amount','type':'FLOAT'},
                {'name':'settlement_amount','type':'FLOAT'},
                {'name':'adjustment','type':'FLOAT'},
                {'name':'net_settlement_amount','type':'FLOAT'},
                {'name':'from','type':'TIMESTAMP'},
                {'name':'till','type':'TIMESTAMP'},
                {'name':'status','type':'STRING'},
                {'name':'utr_no','type':'STRING'},
                {'name':'settlement_date','type':'TIMESTAMP'},
                {'name':'settlement_type','type':'STRING'},
                {'name':'settlement_charge','type':'FLOAT'},
                {'name':'settlement_tax','type':'FLOAT'},
                {'name':'remarks','type':'STRING'}  
                
        ]
        
        #Specifying the header column            
        header_list_upper = ['Id',
                        'total_transaction_amount',
                        'settlement_amount',
                        'adjustment',
                        'net_settlement_amount',
                        'from',
                        'till',
                        'status',
                        'utr_no',
                        'settlement_date',
                        'settlement_type',
                        'settlement_charge',
                        'settlement_tax',
                        'remarks']
        
        upper_list1= ['Id',
                'status',
                'utr_no',
                'settlement_type',
                'remarks']
        
        upper_list2=['total_transaction_amount',
                'settlement_amount',
                'adjustment',
                'net_settlement_amount',
                'settlement_charge',
                'settlement_tax']
        print('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/CashFreePaymentsSettlement Recon Report/Settlement Recon Report '+str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)  +' - '+ str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)+'.csv')
        
        upper_df = pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/CashFreePaymentsSettlement Recon Report/Settlement Recon Report '+str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)  +' - '+ str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)+'.csv', nrows=1,skiprows=1, names=header_list_upper,parse_dates = (['from','till','settlement_date']))
        
        #upper_df = pd.read_csv('Settlement Summary Report 16 Aug 2022 - 16 Aug 2022.csv', nrows=4,skiprows=1, names=header_list_upper,parse_dates = (['from','till','settlement_date']))
        
        upper_df[upper_list1]=upper_df[upper_list1].astype(str)
        upper_df[upper_list2]=upper_df[upper_list2].astype(float)
        
        upper_df.to_gbq(destination_table='sm_recon.wallet_cashfree_settlement_summary_upper', project_id='spicemoney-dwh', if_exists='replace' , table_schema = upper_schema)
        upper_df.to_gbq(destination_table='prod_sm_recon.prod_wallet_cashfree_settlement_summary_upper', project_id='spicemoney-dwh', if_exists='append' , table_schema = upper_schema)
        print("Summary File Upper part loading completed")
        
        print("Summary file lower part loading started")
        
        lower_schema=[{'name':'event_id','type':'STRING'},
                {'name':'event_type','type':'STRING'},
                {'name':'sale_type','type':'STRING'},
                {'name':'event_currency','type':'STRING'},
                {'name':'event_time','type':'TIMESTAMP'},
                {'name':'processed_on','type':'TIMESTAMP'},
                {'name':'status','type':'STRING'},
                {'name':'event_amount','type':'FLOAT'},
                {'name':'event_settlement_amount','type':'FLOAT'},
                {'name':'settlement_date','type':'TIMESTAMP'},
                {'name':'utr','type':'STRING'},
                {'name':'refund_type','type':'STRING'},
                {'name':'refund_arn','type':'STRING'},
                {'name':'adjustment_remarks','type':'STRING'},
                {'name':'merchant_reference_id','type':'STRING'},
                {'name':'cashfree_reference_id','type':'STRING'},
                {'name':'customer_name','type':'STRING'},
                {'name':'customer_phone','type':'STRING'},
                {'name':'customer_email','type':'STRING'},
                {'name':'currency','type':'STRING'},
                {'name':'transaction_amount','type':'FLOAT'},
                {'name':'transaction_service_charge','type':'FLOAT'},
                {'name':'txn_st_gst','type':'FLOAT'},
                {'name':'net_settlement_amount','type':'FLOAT'},
                {'name':'transaction_time','type':'TIMESTAMP'},
                {'name':'payment_mode','type':'STRING'},
                {'name':'bank_name','type':'STRING'},
                {'name':'auth_id','type':'STRING'},
                {'name':'card_type_scheme','type':'STRING'},
                {'name':'vendor_id_1','type':'STRING'},
                {'name':'vendor_amount_1','type':'FLOAT'},
                {'name':'vendor_id_2','type':'STRING'},
                {'name':'vendor_amount_2','type':'FLOAT'},
                {'name':'vendor_id_3','type':'STRING'},
                {'name':'vendor_amount_3','type':'FLOAT'},
                {'name':'vendor_id_4','type':'STRING'},
                {'name':'vendor_amount_4','type':'FLOAT'},
                {'name':'vendor_id_5','type':'STRING'},
                {'name':'vendor_amount_5','type':'FLOAT'},
                {'name':'key_1','type':'STRING'},
                {'name':'value_1','type':'STRING'},
                {'name':'key_2','type':'STRING'},
                {'name':'value_2','type':'STRING'},
                {'name':'key_3','type':'STRING'},
                {'name':'value_3','type':'STRING'},
                {'name':'key_4','type':'STRING'},
                {'name':'value_4','type':'STRING'},
                {'name':'key_5','type':'STRING'},
                {'name':'value_5','type':'STRING'},
                {'name':'key_6','type':'STRING'},
                {'name':'value_6','type':'STRING'},
                {'name':'key_7','type':'STRING'},
                {'name':'value_7','type':'STRING'},
                {'name':'key_8','type':'STRING'},
                {'name':'value_8','type':'STRING'},
                {'name':'key_9','type':'STRING'},
                {'name':'value_9','type':'STRING'},
                {'name':'key_10','type':'STRING'},
                {'name':'value_10','type':'STRING'}
                
        ]
        
        #Specifying the header column            
        lower_header_list = ['event_id',
                        'event_type',
                        'sale_type',
                        'event_currency',
                        'event_time',
                        'processed_on',
                        'status',
                        'event_amount',
                        'event_settlement_amount',
                        'settlement_date',
                        'utr',
                        'refund_type',
                        'refund_arn',
                        'adjustment_remarks',
                        'merchant_reference_id',
                        'cashfree_reference_id',
                        'customer_name',
                        'customer_phone',
                        'customer_email',
                        'currency',
                        'transaction_amount',
                        'transaction_service_charge',
                        'txn_st_gst',
                        'net_settlement_amount',
                        'transaction_time',
                        'payment_mode',
                        'bank_name',
                        'auth_id',
                        'card_type_scheme',
                        'vendor_id_1',
                        'vendor_amount_1',
                        'vendor_id_2',
                        'vendor_amount_2',
                        'vendor_id_3',
                        'vendor_amount_3',
                        'vendor_id_4',
                        'vendor_amount_4',
                        'vendor_id_5',
                        'vendor_amount_5',
                        'key_1',
                        'value_1',
                        'key_2',
                        'value_2',
                        'key_3',
                        'value_3',
                        'key_4',
                        'value_4',
                        'key_5',
                        'value_5',
                        'key_6',
                        'value_6',
                        'key_7',
                        'value_7',
                        'key_8',
                        'value_8',
                        'key_9',
                        'value_9',
                        'key_10',
                        'value_10']
        
        lower_list1= ['event_id',
                'event_type',
                'sale_type',
                'event_currency',
                'status',
                'utr',
                'refund_type',
                'refund_arn',
                'adjustment_remarks',
                'merchant_reference_id',
                'cashfree_reference_id',
                'customer_name',
                'customer_phone',
                'customer_email',
                'currency',
                'payment_mode',
                'bank_name',
                'auth_id',
                'card_type_scheme',
                'vendor_id_1',
                'vendor_id_2',
                'vendor_id_3',
                'vendor_id_4',
                'vendor_id_5',
                'key_1',
                'value_1',
                'key_2',
                'value_2',
                'key_3',
                'value_3',
                'key_4',
                'value_4',
                'key_5',
                'value_5',
                'key_6',
                'value_6',
                'key_7',
                'value_7',
                'key_8',
                'value_8',
                'key_9',
                'value_9',
                'key_10',
                'value_10']
        
        lower_list2=['event_amount',
                'event_settlement_amount',
                'transaction_amount',
                'transaction_service_charge',
                'txn_st_gst',
                'net_settlement_amount',
                'vendor_amount_1',
                'vendor_amount_2',
                'vendor_amount_3',
                'vendor_amount_4',
                'vendor_amount_5']
        # Reading data from excel to dataframe
        lower_df = pd.read_csv('gs://sm-prod-rpa/'+str(current_year)+'/'+str(current_month)+'/'+str(current_day)+'/CashFreePaymentsSettlement Recon Report/Settlement Recon Report '+str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)  +' - '+ str(previous_day)+' '+ str(current_mon)+' ' +str(current_year)+'.csv', skiprows=6, names=lower_header_list,parse_dates = (['event_time','processed_on','settlement_date','transaction_time']))
        
        lower_df[lower_list1]=lower_df[lower_list1].astype(str)
        lower_df[lower_list2]=lower_df[lower_list2].astype(float)
        
        lower_df.to_gbq(destination_table='sm_recon.wallet_cashfree_settlement_recon_detail_lower', project_id='spicemoney-dwh', if_exists='replace' , table_schema = lower_schema)
        lower_df.to_gbq(destination_table='prod_sm_recon.prod_wallet_cashfree_settlement_recon_detail_lower', project_id='spicemoney-dwh', if_exists='append' , table_schema = upper_schema)
        print("Summary file lower part loading completed")
        print("Summary file loading completed")
        print("-----------------------------------------------------------")
        
        #---------------------------------------------------------------------------------------------------------------------
        #--RECON OUTPUT PART 1(15 Aug 2022)
        #---------------------------------------------------------------------------------------------------------------------
        

        sql_query="""
        
        select order_id,reference_id,transaction_time,WALLET_TRANS_REPORT_OUTPUT.client_id as client_id,payment_mode,bank_name,transaction_status,Cashfree_Detail_Spice_Amount,SUM_OF_SERVICE_CHARGE,ST_GST,SUM_OF_SETTLEMENT_AMOUNT,SUM_SURCHARGE_AMT,Cashfree_Net_Charges,coalesce(Spice_Amount,0) as Spice_Amount ,coalesce(Spice_Amount_PG_Charges,0) as Spice_Amount_PG_Charges,coalesce(SUM_OF_SETTLEMENT_AMOUNT,0)-coalesce(Spice_Amount,0) as Difference_Txn_Amt,coalesce(Cashfree_Net_Charges,0)-coalesce(Spice_Amount_PG_Charges,0) as Difference_PG_Charges
        ,coalesce(Cashfree_Net_Charges,0)/coalesce(Cashfree_Detail_Spice_Amount,0) as Cashfree_Percentage ,
        coalesce(Spice_Amount_PG_Charges,0)/coalesce(Cashfree_Detail_Spice_Amount,0) as Spice_Percentage
        from
        (select transaction_time,order_id,reference_id,sum(amount) as Cashfree_Detail_Spice_Amount,sum(service_charge) as SUM_OF_SERVICE_CHARGE,sum(st_gst) as ST_GST,sum(surcharge_amount) as SUM_SURCHARGE_AMT,sum(service_charge)+sum(st_gst)+sum(surcharge_amount)  as Cashfree_Net_Charges ,transaction_status,sum(settlement_amount) as SUM_OF_SETTLEMENT_AMOUNT,payment_mode,bank_name,settlement from `sm_recon.wallet_cashfree_detail_log` where transaction_status="SUCCESS" and date(transaction_time) =@date group by order_id,reference_id,payment_mode,bank_name,transaction_time,transaction_status,settlement
        ) as CASH_FREE_DETAIL_OUTPUT
        FULL OUTER JOIN
        (
        select trans_id,sum(trans_amt) as Spice_Amount,trans_type,trans_status,trans_date,comments,client_id from `travelunion-dwh.prod_travel_app.travel_wallet_trans_report` where comments in ('Travel Wallet Loading PG') and trans_status="SUCCESS" and date(trans_date) =@date group by trans_id,trans_type,trans_status,client_id,comments,trans_date
        ) as WALLET_TRANS_REPORT_OUTPUT
        ON WALLET_TRANS_REPORT_OUTPUT.trans_id=CASH_FREE_DETAIL_OUTPUT.order_id
        FULL OUTER JOIN
        (
        select trans_id,sum(trans_amt) as Spice_Amount_PG_Charges,trans_type,trans_status,trans_date,comments,client_id from `travelunion-dwh.prod_travel_app.travel_wallet_trans_report` where comments in ('Travel Wallet Loading PG Charges') and trans_status="SUCCESS" and date(trans_date) =@date group by trans_id,trans_type,trans_status,client_id,comments,trans_date
        ) as WALLET_TRANS_REPORT_PG_CHARGES_OUTPUT
        ON WALLET_TRANS_REPORT_PG_CHARGES_OUTPUT.trans_id=CASH_FREE_DETAIL_OUTPUT.order_id
        
        """
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.wallet_cashfree_vs_spice_tu_agent', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_wallet_cashfree_vs_spice_tu_agent', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()
        print("wallet_cashfree_vs_spice_tu_agent completed")
        print("-----------------------------------------------------------")
        
        #---------------------------------------------------------------------------------------------------------------------
        #--RECON OUTPUT PART 2(15 Aug 2022)
        #---------------------------------------------------------------------------------------------------------------------
        

        sql_query="""select (@date) as recon_date,* from(
        select PAYMENT_LINK_OUTPUT.order_id as Order_Id,
        PAYMENT_LINK_OUTPUT.reference_id as Ref_Id,
        PAYMENT_LINK_OUTPUT.description as Description,
        PAYMENT_LINK_OUTPUT.payment_mode as Payment_Mode,
        PAYMENT_LINK_OUTPUT.transaction_status as Transaction_Status,
        SUM_OF_SERVICE_CHARGE,ST_GST,
        PAYEMENT_LINK_AMOUNT,
        PaymentLink_Settlement_Amount,
        SUM_OF_SETTLEMENT_AMOUNT,
        coalesce(PaymentLink_Settlement_Amount,0)-coalesce(SUM_OF_SETTLEMENT_AMOUNT,0) as diff
        from 
        (select order_id,reference_id,payment_mode,bank_name,transaction_status,sum(amount) as Amount,sum(service_charge) as SUM_OF_SERVICE_CHARGE,sum(st_gst) as ST_GST,sum(settlement_amount) as SUM_OF_SETTLEMENT_AMOUNT,sum(surcharge_amount) as SUM_SURCHARGE_AMT from `sm_recon.wallet_cashfree_detail_log` where transaction_status="SUCCESS" and order_id like ("%CFPay%")and date(transaction_time)=@date group by order_id,reference_id,payment_mode,bank_name,transaction_time,transaction_status,settlement
        ) as CASH_FREE_DETAIL_OUTPUT
        FULL OUTER JOIN
        (
        Select order_id,reference_id,description,sum(amount) as PAYEMENT_LINK_AMOUNT,sum(service_charge) as p_service_charge,sum(st_gst) as p_st_gst,sum(settlement_amount) as PaymentLink_Settlement_Amount,payment_mode,transaction_status from
        `sm_recon.wallet_cashfree_payment_link_transactions_log` where date(transaction_time)=@date and transaction_status="SUCCESS"  group by order_id,reference_id,description,payment_mode,transaction_status
        ) as PAYMENT_LINK_OUTPUT
        ON PAYMENT_LINK_OUTPUT.order_id=CASH_FREE_DETAIL_OUTPUT.order_id)
        """
        
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.wallet_cashfree_vs_payment_link', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_wallet_cashfree_vs_payment_link', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()

        
        
        #---------------------------------------------------------------------------------------------------------------------
        #--LIMIT
        #---------------------------------------------------------------------------------------------------------------------
        

        sql_query="""
        select (@date) as recon_date, * from(
        
        select "TU_PG" as Service,"Cashfrees" as Aggregator,MIN_TRANSACTION_ID,MIN_TRANSACTION_AMOUNT,
                MAX_TRANSACTION_ID,MAX_TRANSACTION_AMOUNT  from 
                (
                SELECT trans_id as MIN_TRANSACTION_ID,trans_amt as MIN_TRANSACTION_AMOUNT,trans_status,Trans_date FROM `travelunion-dwh.prod_travel_app.travel_wallet_trans_report`
                WHERE trans_amt=(SELECT MIN(trans_amt) FROM `travelunion-dwh.prod_travel_app.travel_wallet_trans_report` where  Date(Trans_date) =@date and  trans_status="SUCCESS" 
        and  comments in ('Travel Wallet Loading PG')) and Date(Trans_date) =@date limit 1
                ) as t1,
                (
                SELECT trans_id as MAX_TRANSACTION_ID,trans_amt as MAX_TRANSACTION_AMOUNT,trans_status,Trans_date FROM `travelunion-dwh.prod_travel_app.travel_wallet_trans_report`
                WHERE trans_amt=(SELECT MAX(trans_amt) FROM `travelunion-dwh.prod_travel_app.travel_wallet_trans_report` where  Date(Trans_date) =@date and  trans_status="SUCCESS" 
        and  comments in ('Travel Wallet Loading PG')) and Date(Trans_date) =@date limit 1
                ) as t2
        )
        
        """
        
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.wallet_cashfree_tu_pg_limit_detail', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_wallet_cashfree_tu_pg_limit_detail', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()

        
        
        
        
        #---------------------------------------------------------------------------------------------------------------------
        #---INternal file summary
        #---------------------------------------------------------------------------------------------------------------------
        

        sql_query="""select (@date) as recon_date, * from(select sum(trans_amt) as trans_amt, trans_type,trans_status,comments from `travelunion-dwh.prod_travel_app.travel_wallet_trans_report` where 
        date(trans_date)=@date and  comments in ('Travel Wallet Loading PG','Travel Wallet Loading PG Charges Reversal',
        'Travel Wallet Loading PG Charges') group by trans_type,trans_status,comments) """
        
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.wallet_cashfree_tu_wallet_log_summary', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_wallet_cashfree_tu_wallet_log_summary', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()

        
        
        #---------------------------------------------------------------------------------------------------------------------
        #---Partner file summary
        #---------------------------------------------------------------------------------------------------------------------
        

        sql_query="""
        select sum(amount) as Amount,sum(service_charge) as SUM_OF_SERVICE_CHARGE,sum(st_gst) as ST_GST,sum(settlement_amount) as SUM_OF_SETTLEMENT_AMOUNT,
        payment_mode,bank_name,date(transaction_time) as transaction_time,transaction_status,sum(surcharge_amount) as SUM_SURCHARGE_AMT from `sm_recon.wallet_cashfree_detail_log` where  date(transaction_time)=@date group by payment_mode,bank_name,date(transaction_time),transaction_status   
        """
        
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.wallet_cashfree_detail_report_summary', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_wallet_cashfree_detail_report_summary', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()

        
        #---------------------------------------------------------------------------------------------------------------------
        #---Partner file summary
        #---------------------------------------------------------------------------------------------------------------------
        
        
        sql_query="""select (@date) as recon_date, * from(Select sum(amount) as PAYEMENT_LINK_AMOUNT,sum(settlement_amount) as PaymentLink_Settlement_Amount,sum(service_charge) as PaymentLink_Service_Charge,sum(st_gst) as PaymentLink_ST_GST,
        payment_mode,transaction_status from `sm_recon.wallet_cashfree_payment_link_transactions_log` where 
        date(transaction_time)=@date group by payment_mode,transaction_status)"""

        
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.wallet_cashfree_payment_link_report_summary', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_wallet_cashfree_payment_link_report_summary', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()

        

        #---------------------------------------------------------------------------------------------------------------------
        #---Partner file summary
        #---------------------------------------------------------------------------------------------------------------------
        

        sql_query="""select  settlement_amount,adjustment,net_settlement_amount, date (settlement_date) as settlement_date 
        from `sm_recon.wallet_cashfree_settlement_summary_upper` where date(settlement_date)=@date
        """
        
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.wallet_cashfree_settlement_summary', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_wallet_cashfree_settlement_summary', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()

        

        #---------------------------------------------------------------------------------------------------------------------
        #---Partner file summary
        #---------------------------------------------------------------------------------------------------------------------
        

        sql_query="""select sale_type,sum(event_settlement_amount) as sum_event_settlement,date(settlement_date) as 
        sum_setlement_date,sum(net_settlement_amount) as sum_net_settlement_amnt,payment_mode,bank_name 
        from `sm_recon.wallet_cashfree_settlement_recon_detail_lower` where date(settlement_date)=@date 
        group by sale_type,date(settlement_date),payment_mode,bank_name 
        """
        
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.wallet_cashfree_settlement_recon_detail_summary', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_wallet_cashfree_settlement_recon_detail_summary', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()

        
        
        #---------------------------------------------------------------------------------------------------------------------
        # --RECON TRACKER OUTPUT   ---PAYMENT LINK DATE IS AN ISSUE check rest queries also.
        #---------------------------------------------------------------------------------------------------------------------
        

        sql_query="""select Trans_Date,Txn_Count_As_Per_Wallet_Trans_Report,Sum_Of_Amount_As_Per_Spice_Wallet_Credit_TU,Sum_Of_Charges_Amount_As_Per_Spice_TU_Wallet,Sum_Of_Charges_Reversal_Amount_As_Per_Spice_TU_Wallet,
                Sum_Of_Charges_Amount_As_Per_Spice_TU_Wallet-Sum_Of_Charges_Reversal_Amount_As_Per_Spice_TU_Wallet as  Sum_of_net_Charges_Amount_As_Per_Spice_TU_Wallet ,Sum_Of_Amount_As_Per_Cashfress_Report,Sum_Of_Service_Charge_As_Per_Cashfree_Detail_Report,Sum_Of_ST_GST_As_Per_Cashfree_Detail_Report,Sum_Of_Surcharge_As_Per_Cashfree_Detail_Report,Sum_Of_Service_Charge_As_Per_Cashfree_Detail_Report+Sum_Of_ST_GST_As_Per_Cashfree_Detail_Report+Sum_Of_Surcharge_As_Per_Cashfree_Detail_Report as  Sum_Of_Net_Charges_As_Per_Cashfree_Detail_Report,Sum_Of_Settlement_Amount_As_Per_Cashfree_Detail_Report,
                Sum_Of_Amount_As_Per_Spice_Wallet_Credit_TU-Sum_Of_Settlement_Amount_As_Per_Cashfree_Detail_Report as  Diff_Spice_vs_Cashfree_Amt,
                Sum_Of_Amount_As_Per_Payment_Link_Report,Sum_Of_Settlement_Amount_As_Per_Payment_Link_Report,
        Sum_Of_Settlement_Amount_As_Per_Settlement_Summary,Sum_Of_Adjustment_Amount_As_Per_Settlement_Summary,Sum_Of_Net_Settlement_Amount_As_Per_Settlement_Summary
                from
                (
                select Trans_Date,Txn_Count_As_Per_Wallet_Trans_Report,Sum_Of_Amount_As_Per_Spice_Wallet_Credit_TU,coalesce(Sum_Of_Charges_Amount_As_Per_Spice_TU_Wallet,0) as Sum_Of_Charges_Amount_As_Per_Spice_TU_Wallet,coalesce(Sum_Of_Charges_Reversal_Amount_As_Per_Spice_TU_Wallet,0) as Sum_Of_Charges_Reversal_Amount_As_Per_Spice_TU_Wallet,
                coalesce(Sum_Of_Amount_As_Per_Cashfress_Report,0) as Sum_Of_Amount_As_Per_Cashfress_Report,coalesce(Sum_Of_Service_Charge_As_Per_Cashfree_Detail_Report,0) as Sum_Of_Service_Charge_As_Per_Cashfree_Detail_Report,coalesce(Sum_Of_ST_GST_As_Per_Cashfree_Detail_Report,0) as Sum_Of_ST_GST_As_Per_Cashfree_Detail_Report,coalesce(Sum_Of_Surcharge_As_Per_Cashfree_Detail_Report,0) as Sum_Of_Surcharge_As_Per_Cashfree_Detail_Report,coalesce(Sum_Of_Settlement_Amount_As_Per_Cashfree_Detail_Report,0) as Sum_Of_Settlement_Amount_As_Per_Cashfree_Detail_Report,
                coalesce(Sum_Of_Amount_As_Per_Payment_Link_Report,0) as Sum_Of_Amount_As_Per_Payment_Link_Report,coalesce(Sum_Of_Settlement_Amount_As_Per_Payment_Link_Report,0) as Sum_Of_Settlement_Amount_As_Per_Payment_Link_Report,
                Sum_Of_Settlement_Amount_As_Per_Settlement_Summary,Sum_Of_Adjustment_Amount_As_Per_Settlement_Summary,
                coalesce(Sum_Of_Settlement_Amount_As_Per_Settlement_Summary,0)-ABS(coalesce(Sum_Of_Adjustment_Amount_As_Per_Settlement_Summary,0)) as Sum_Of_Net_Settlement_Amount_As_Per_Settlement_Summary
                from
                (
                select count(*) as  Txn_Count_As_Per_Wallet_Trans_Report , date(trans_date) as Trans_Date from `travelunion-dwh.prod_travel_app.travel_wallet_trans_report` where comments in ('Travel Wallet Loading PG',
                'Travel Wallet Loading PG Charges Reversal','Travel Wallet Loading PG Charges')  and date(trans_date)=@date group by date(trans_date)
                )as t1,
                (
                select sum(trans_amt)  as  Sum_Of_Amount_As_Per_Spice_Wallet_Credit_TU  from `travelunion-dwh.prod_travel_app.travel_wallet_trans_report` where comments in ('Travel Wallet Loading PG')  and date(trans_date)=@date 
                ) as t2,
                (
                select sum(trans_amt)  as  Sum_Of_Charges_Amount_As_Per_Spice_TU_Wallet  from `travelunion-dwh.prod_travel_app.travel_wallet_trans_report` where comments in ('Travel Wallet Loading PG Charges') and date(trans_date)=@date 
                ) as t3,
                (
                select sum(trans_amt)  as  Sum_Of_Charges_Reversal_Amount_As_Per_Spice_TU_Wallet  from `travelunion-dwh.prod_travel_app.travel_wallet_trans_report` where comments in ('Travel Wallet Loading PG Charges Reversal')  and date(trans_date)=@date 
                ) as t4,
                (
                select sum(amount) as  Sum_Of_Amount_As_Per_Cashfress_Report ,sum(service_charge) as  Sum_Of_Service_Charge_As_Per_Cashfree_Detail_Report ,sum(st_gst) as Sum_Of_ST_GST_As_Per_Cashfree_Detail_Report,sum(surcharge_amount) as Sum_Of_Surcharge_As_Per_Cashfree_Detail_Report,sum(settlement_amount) as Sum_Of_Settlement_Amount_As_Per_Cashfree_Detail_Report from `sm_recon.wallet_cashfree_detail_log` where transaction_status="SUCCESS" and date(transaction_time)=@date
                ) as t5,
                (
                Select sum(amount) as Sum_Of_Amount_As_Per_Payment_Link_Report,sum(settlement_amount) as Sum_Of_Settlement_Amount_As_Per_Payment_Link_Report from `sm_recon.wallet_cashfree_payment_link_transactions_log` where date(transaction_time)=@date and transaction_status="SUCCESS" 
                ) as t6,
                (
                select sum(event_settlement_amount) as Sum_Of_Settlement_Amount_As_Per_Settlement_Summary from `sm_recon.wallet_cashfree_settlement_recon_detail_lower` where date(settlement_date)=@date and sale_type="CREDIT"
                ) as t7,
                (
                select sum(event_settlement_amount) as Sum_Of_Adjustment_Amount_As_Per_Settlement_Summary from `sm_recon.wallet_cashfree_settlement_recon_detail_lower` where date(settlement_date)=@date and sale_type="DEBIT"
                ) as t8
                )"""
        
        job_config = bigquery.QueryJobConfig(destination='spicemoney-dwh.sm_recon.wallet_cashfree_recon_tracker', write_disposition='WRITE_TRUNCATE' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])
        job_config2 = bigquery.QueryJobConfig(destination='spicemoney-dwh.prod_sm_recon.prod_wallet_cashfree_recon_tracker', write_disposition='WRITE_APPEND' ,  query_parameters=[bigquery.ScalarQueryParameter("date", "DATE" , current_date)])

        query_job = client.query(sql_query, job_config=job_config)
        query_job = client.query(sql_query, job_config=job_config2)

        results = query_job.result()

        print("success")
        # SQL Queries End
        print('Recon Success for {} at {}'.format(dates, times))
        with open('/home/sdlreco/crons/wallet_cashfree/stat/stat-'+str(dates)+'.txt', 'w') as f:
            f.write('1')
            f.close()


import sys
sys.path.insert(0, '/home/sdlreco/crons/smarten/')
import payload as smarten

wallet_cashfree = ['182eebee6cb','182eec291a0','182eec52dea','182eec770e8','182eec9ccbe','182eecc5cf4','182fc9249e0','1838cb22026','1838cb992ce','1838cc1fedc']
with open('/home/sdlreco/crons/wallet_cashfree/stat/stat-'+str(dates)+'.txt', 'r') as f:
    lines = f.read().splitlines()
    f.close()
if('1' in lines):
    print('Tried at {}, but reco already done !!'.format(times))
else:
    main()
    for ids in wallet_cashfree:
        smarten.payload(ids)
    print('Refreshed : wallet_cashfree')
