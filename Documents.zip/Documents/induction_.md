Spice Money creates Partners(distributer) in Market-> Partners create SMA

SMA - Spice Money Adhikari (any agent/retailers working with Spice Money Distributors)



   **AGENT ONBOARDING**'

Fill Business associate form-> KYC's submittion->Payment details mapped 

![image-20220705135209189](C:\Users\roop.sidhu_spicemone\AppData\Roaming\Typora\typora-user-images\image-20220705135209189.png)



![image-20220705143331372](C:\Users\roop.sidhu_spicemone\AppData\Roaming\Typora\typora-user-images\image-20220705143331372.png)







Marketing Tools





